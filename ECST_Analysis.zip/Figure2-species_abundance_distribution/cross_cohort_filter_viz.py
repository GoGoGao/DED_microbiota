#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cross_cohort_filter_viz.py

Usage
-----
    python cross_cohort_filter_viz.py \
        --abundance total_relative.tsv \
        --metadata  group.tsv \
        --outdir    results/ \
        --min-cohorts 2 \
        --top-filtered 10 \
        --dpi 300

Dependencies: pandas, numpy, matplotlib, scipy, kneed, openpyxl
Install:      pip install pandas numpy matplotlib scipy kneed openpyxl
"""

import argparse
import os
import sys
import pandas as pd
import numpy as np
import matplotlib
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
matplotlib.rcParams['svg.fonttype'] = 'none'
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patheffects as pe
import matplotlib.patches as mpatches
from scipy.stats import gaussian_kde
from kneed import KneeLocator
import warnings
warnings.filterwarnings('ignore')


COHORT_PALETTE = [
    '#3C5488', '#E64B35', '#4DBBD5', '#00A087',
    '#F39B7F', '#8491B4', '#91D1C2', '#DC0000',
    '#7E6148', '#B09C85',
]

SPECIES_PALETTE = [
    '#D94F4F', '#3674B5', '#1A7A5E', '#E08A28', '#8555B3',
    '#2BB57A', '#C74E8A', '#5DA4D9', '#A67B2E', '#6B8E23',
    '#E06060', '#4B7FA8', '#9C5E2E', '#7CB87C', '#B074C8',
    '#D48C6A', '#408080', '#C25D5D', '#6A6AAD', '#88B04B',
]


def short_name(raw):
    for part in raw.split('|'):
        if part.startswith('s__'):
            return part[3:].replace('_', ' ')
    return raw.split('|')[-1].replace('_', ' ')


def setup_style(fontscale=1.0):
    fs = int(14 * fontscale)
    plt.rcParams.update({
        'font.family': 'Times New Roman',
        'font.size': fs,
        'font.weight': 'normal',
        'axes.linewidth': 0.8,
        'axes.labelsize': fs + 2,
        'axes.titlesize': fs + 2,
        'axes.titleweight': 'normal',
        'xtick.major.width': 0.6,
        'ytick.major.width': 0.6,
        'xtick.major.size': 4,
        'ytick.major.size': 4,
        'xtick.labelsize': fs,
        'ytick.labelsize': fs,
        'legend.fontsize': fs - 2,
        'legend.frameon': False,
        'figure.dpi': 300,
        'savefig.dpi': 300,
        'savefig.bbox': 'tight',
        'savefig.facecolor': 'white',
        'savefig.pad_inches': 0.15,
    })
    return fs


def load_data(abund_path, meta_path):
    abund = pd.read_csv(abund_path, sep='\t', index_col=0)
    abund = abund.apply(pd.to_numeric, errors='coerce').fillna(0)

    if abund.max().max() <= 1.5:
        abund = abund * 100
        print("  Detected proportion scale (0-1), converted to percentage.")

    meta = pd.read_csv(meta_path, sep='\t')
    for col in ['Group', 'Country', 'SamplingSite', 'Dataset']:
        if col in meta.columns:
            meta[col] = meta[col].astype(str).str.strip()

    common = sorted(set(abund.columns) & set(meta['Sample']))
    if not common:
        sys.exit("ERROR: no overlapping samples between abundance and metadata.")

    abund = abund[common]
    meta = meta[meta['Sample'].isin(common)].copy()
    meta = meta.sort_values(['Dataset', 'Sample']).set_index('Sample')

    print(f"  Loaded {abund.shape[0]} species x {len(common)} samples, "
          f"{meta['Dataset'].nunique()} cohorts")
    return abund, meta


def run_kneedle(cohort_means, x_max=5.0, step=0.01):
    thresholds = np.arange(step, x_max + step, step)
    curves = {}
    knees = {}
    for mc in [2, 3, 4]:
        counts = [int(((cohort_means >= t).sum(axis=1) >= mc).sum())
                  for t in thresholds]
        curves[mc] = counts
        kn = KneeLocator(thresholds, counts, curve='convex',
                         direction='decreasing', S=1.0,
                         interp_method='polynomial')
        knees[mc] = kn
    return thresholds, curves, knees


def _save(fig, base, dpi):
    for ext in ('pdf', 'jpg', 'svg'):
        path = f'{base}.{ext}'
        fig.savefig(path, dpi=dpi)
        print(f"  saved: {path}")
    plt.close(fig)


def plot_fig_a(cohort_means, cohort_colors, fs, outdir, dpi):
    cohorts = cohort_means.columns.tolist()
    THR_MARK = 1.0
    log_thr = np.log10(THR_MARK)

    fig, ax = plt.subplots(figsize=(10, 6))

    bins = np.linspace(-4.5, 2.0, 55)
    bin_w = bins[1] - bins[0]

    for c in cohorts:
        v = cohort_means[c].values.astype(float)
        v_pos = v[v > 0]
        log_v = np.log10(v_pos)
        n_above = int((v_pos >= THR_MARK).sum())

        counts_hist, _ = np.histogram(log_v, bins=bins)
        bin_centers = (bins[:-1] + bins[1:]) / 2
        ax.bar(bin_centers, counts_hist, width=bin_w * 0.92,
               color=cohort_colors[c], alpha=0.12, edgecolor='none')

        try:
            kde = gaussian_kde(log_v, bw_method=0.18)
            xk = np.linspace(-4.5, 2.0, 500)
            y_kde = kde(xk) * len(log_v) * bin_w
            ax.plot(xk, y_kde, color=cohort_colors[c], lw=2.0, alpha=0.85,
                    label=f'{c} (n >= {THR_MARK}%: {n_above})')
        except Exception:
            ax.plot([], [], color=cohort_colors[c], lw=2.0,
                    label=f'{c} (n >= {THR_MARK}%: {n_above})')

    ax.axvline(log_thr, color='#222222', linewidth=1.5, linestyle='--', zorder=5)

    ylim_top = ax.get_ylim()[1]
    ax.text(log_thr + 0.08, ylim_top * 0.55,
            f'{THR_MARK}%',
            fontsize=fs, color='#C0392B', va='center',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white',
                      edgecolor='#C0392B', alpha=0.92, linewidth=0.8))

    ax.axvspan(log_thr, 2.2, alpha=0.04, color='#2166AC', zorder=0)

    ax.set_xticks([-4, -3, -2, -1, 0, 1, 2])
    ax.set_xticklabels(['10$^{-4}$', '10$^{-3}$', '10$^{-2}$', '10$^{-1}$', '1', '10', '100'])
    ax.set_xlim(-4.5, 2.2)
    ax.set_xlabel('Cohort mean relative abundance (%)')
    ax.set_ylabel('No. of species')
    ax.set_title('Per-cohort species abundance distribution')
    ax.legend(fontsize=fs - 3, ncol=1, loc='upper right',
              handlelength=1.5, labelspacing=0.3)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    _save(fig, os.path.join(outdir, 'fig_A_abundance_distribution'), dpi)

    tsv_rows = []
    for c in cohorts:
        v = cohort_means[c].values.astype(float)
        v_pos = v[v > 0]
        for val in v_pos:
            tsv_rows.append({'Cohort': c, 'Cohort_Mean_Abundance_%': val})
    return pd.DataFrame(tsv_rows)


def plot_fig_b(thresholds, curves, knees, elbow, elbow_y, mc_main, fs, outdir, dpi):
    fig, ax = plt.subplots(figsize=(9, 6))

    sty = {2: ('#C0392B', 2.2), 3: ('#2166AC', 1.6), 4: ('#27AE60', 1.6)}
    for mc, (col, lw) in sty.items():
        ax.plot(thresholds, curves[mc], color=col, lw=lw, alpha=0.9,
                label=f'>= {mc} cohorts')
        kn = knees[mc]
        if kn.knee:
            ky = curves[mc][np.argmin(np.abs(thresholds - kn.knee))]
            ax.scatter(kn.knee, ky, color=col, s=50, zorder=6,
                       edgecolors='white', linewidth=1.0)

    ax.annotate(
        f'Elbow = {elbow}%\n({elbow_y} spp, >=2)',
        xy=(elbow, elbow_y),
        xytext=(elbow + 0.65, elbow_y + 10),
        fontsize=fs - 1, color='#C0392B',
        arrowprops=dict(arrowstyle='->', color='#C0392B', lw=1.0,
                        connectionstyle='arc3,rad=0.2'),
        bbox=dict(boxstyle='round,pad=0.3', facecolor='white',
                  edgecolor='#C0392B', alpha=0.95, lw=0.8),
        zorder=8)

    annot_cfg = {
        3: {'color': '#2166AC', 'dx': 0.7, 'dy': 3},
        4: {'color': '#27AE60', 'dx': 1.2, 'dy': 2},
    }
    for mc_ann, cfg in annot_cfg.items():
        if mc_ann in curves:
            n_at = curves[mc_ann][np.argmin(np.abs(thresholds - elbow))]
            ax.annotate(
                f'>={mc_ann} at {elbow}%: {n_at} spp',
                xy=(elbow, n_at),
                xytext=(elbow + cfg['dx'], n_at + cfg['dy']),
                fontsize=fs - 2, color=cfg['color'],
                arrowprops=dict(arrowstyle='->', color=cfg['color'],
                                lw=0.8, connectionstyle='arc3,rad=0.2'),
                bbox=dict(boxstyle='round,pad=0.25', facecolor='white',
                          edgecolor=cfg['color'], alpha=0.9, lw=0.5),
                zorder=7)

    ax.axvline(elbow, color='#C0392B', lw=0.8, ls=':', alpha=0.5)
    ax.axvspan(elbow, thresholds[-1], alpha=0.03, color='#2166AC')
    ax.set_xlabel('Abundance threshold (%)')
    ax.set_ylabel('No. of retained species')
    ax.set_title('Kneedle elbow detection')
    ax.set_xlim(0, 4.2)
    ax.set_ylim(0, min(elbow_y * 6, max(curves[2]) * 0.35))
    ax.legend(loc='upper right', fontsize=fs - 1)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    _save(fig, os.path.join(outdir, 'fig_B_kneedle_elbow'), dpi)

    tsv_df = pd.DataFrame({'Threshold_%': thresholds})
    for mc in [2, 3, 4]:
        tsv_df[f'N_retained_ge{mc}cohorts'] = curves[mc]
    return tsv_df


def plot_fig_c(sp_list, abund, meta, sample_order, cohort_colors,
               title, palette, fs, outdir, out_stem, dpi):
    cohorts = sorted(meta['Dataset'].unique())
    top_data = abund.loc[sp_list, sample_order]
    n_s = len(sample_order)

    fig, ax = plt.subplots(figsize=(max(16, n_s * 0.045), 7))

    xp = np.arange(n_s)
    bottom = np.zeros(n_s)
    for j, sp in enumerate(sp_list):
        ax.bar(xp, top_data.loc[sp].values, bottom=bottom, width=1.0,
               linewidth=0, color=palette[j % len(palette)])
        bottom += top_data.loc[sp].values

    strip_y = -4
    for c in cohorts:
        samps = [s for s in sample_order if meta.loc[s, 'Dataset'] == c]
        idxs = [sample_order.index(s) for s in samps]
        if idxs:
            ax.barh(strip_y, len(idxs), left=min(idxs), height=3.0,
                    color=cohort_colors[c], linewidth=0)
            mid = (min(idxs) + max(idxs)) / 2
            ax.text(mid, strip_y - 3.5, c, fontsize=fs - 4,
                    ha='center', va='top', color=cohort_colors[c],
                    rotation=30)

    ax.set_ylim(strip_y - 8, max(bottom) * 1.05 + 2)
    ax.set_xlim(-0.5, n_s - 0.5)
    ax.set_ylabel('Relative abundance (%)')
    ax.set_xticks([])
    ax.set_title(title, fontsize=fs)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['bottom'].set_visible(False)

    labels = [short_name(sp) for sp in sp_list]
    colors = [palette[j % len(palette)] for j in range(len(sp_list))]
    patches = [mpatches.Patch(color=col, label=lab)
               for col, lab in zip(colors, labels)]
    leg = ax.legend(handles=patches, loc='upper left',
                    bbox_to_anchor=(1.01, 1.0),
                    fontsize=fs - 3, handlelength=1.2,
                    handletextpad=0.4, labelspacing=0.3,
                    borderaxespad=0, borderpad=0.3, frameon=False)
    for txt in leg.get_texts():
        txt.set_fontstyle('italic')

    _save(fig, os.path.join(outdir, out_stem), dpi)

    tsv_rows = []
    for sp in sp_list:
        for s in sample_order:
            tsv_rows.append({
                'Species': short_name(sp),
                'Sample': s,
                'Cohort': meta.loc[s, 'Dataset'],
                'Relative_abundance_%': top_data.loc[sp, s],
            })
    return pd.DataFrame(tsv_rows)


def plot_fig_e(retained, cohort_means, abund, elbow, mc_main, fs, outdir, dpi):
    cohorts = cohort_means.columns.tolist()

    sp_data = []
    for sp in retained:
        gm = abund.loc[sp].mean()
        mcm = cohort_means.loc[sp].max()
        mc_name = cohort_means.loc[sp].idxmax()
        nc = int((cohort_means.loc[sp] >= elbow).sum())
        sp_data.append({
            'Species': short_name(sp),
            'Global_Mean_%': gm,
            'Max_Cohort_Mean_%': mcm,
            'Max_Cohort': mc_name,
            'N_Cohorts_Passing': nc,
        })
    df = pd.DataFrame(sp_data)
    df = df.sort_values('Max_Cohort_Mean_%', ascending=False).reset_index(drop=True)
    n = len(df)

    fig, ax1 = plt.subplots(figsize=(max(12, n * 1.3), 7))

    x = np.arange(n)
    w = 0.35

    c_global = '#4292C6'
    c_max = '#EF6548'

    ax1.bar(x - w / 2, df['Global_Mean_%'], w,
            color=c_global, alpha=0.85, edgecolor='white',
            linewidth=0.5, label='Global mean', zorder=3)
    ax1.bar(x + w / 2, df['Max_Cohort_Mean_%'], w,
            color=c_max, alpha=0.85, edgecolor='white',
            linewidth=0.5, label='Max cohort mean', zorder=3)

    ax1.set_ylabel('Relative abundance (%)', color='#333')
    ax1.set_ylim(0, df['Max_Cohort_Mean_%'].max() * 1.55)
    ax1.spines['top'].set_visible(False)

    for i, row in df.iterrows():
        ax1.text(i + w / 2, row['Max_Cohort_Mean_%'] + 0.5,
                 row['Max_Cohort'], ha='center', va='bottom',
                 fontsize=fs - 5, color=c_max, rotation=55,
                 path_effects=[pe.withStroke(linewidth=2.0, foreground='white')])

    ax2 = ax1.twinx()
    c_cohort = '#2CA02C'
    ax2.plot(x, df['N_Cohorts_Passing'], 'o-',
             color=c_cohort, markersize=9, linewidth=2.2,
             markeredgecolor='white', markeredgewidth=1.2,
             label='N cohorts passing', zorder=5)

    for i, nc in enumerate(df['N_Cohorts_Passing']):
        ax2.text(i, nc + 0.15, str(nc), ha='center', va='bottom',
                 fontsize=fs - 4, color=c_cohort)

    ax2.set_ylabel('No. of cohorts passing', color=c_cohort)
    ax2.set_ylim(0, len(cohorts) + 1.5)
    ax2.set_yticks(range(0, len(cohorts) + 2))
    ax2.spines['top'].set_visible(False)
    ax2.tick_params(axis='y', labelcolor=c_cohort)

    ax1.set_xticks(x)
    ax1.set_xticklabels(df['Species'], rotation=45, ha='right',
                        fontsize=fs - 3, style='italic')
    ax1.set_xlim(-0.6, n - 0.4)
    ax1.set_title(f'Retained species abundance profile '
                  f'(>= {elbow}% in >= {mc_main} cohorts)')

    handles1, labels1 = ax1.get_legend_handles_labels()
    handles2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(handles1 + handles2, labels1 + labels2,
               loc='upper right', fontsize=fs - 3, framealpha=0.9)

    fig.tight_layout()
    _save(fig, os.path.join(outdir, 'fig_E_retained_profile'), dpi)

    return df[['Species', 'Global_Mean_%', 'Max_Cohort_Mean_%',
               'Max_Cohort', 'N_Cohorts_Passing']].copy()


def parse_args():
    p = argparse.ArgumentParser(
        description='Cross-cohort consistency filtering — Figure 2 (A-E)',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__)
    p.add_argument('--abundance', required=True,
                   help='Species relative abundance table (TSV, species x samples)')
    p.add_argument('--metadata', required=True,
                   help='Sample metadata TSV (columns: Sample, Dataset, ...)')
    p.add_argument('--outdir', default='figure2_results',
                   help='Output directory (default: figure2_results)')
    p.add_argument('--min-cohorts', type=int, default=2,
                   help='Minimum cohorts for retention (default: 2)')
    p.add_argument('--top-n', type=int, default=10,
                   help='Top N species for stacked bar plots (default: 10)')
    p.add_argument('--kneedle-range', type=float, default=5.0,
                   help='Max threshold for Kneedle scan (default: 5.0)')
    p.add_argument('--dpi', type=int, default=300,
                   help='Figure DPI (default: 300)')
    p.add_argument('--fontscale', type=float, default=1.0,
                   help='Font scale factor (default: 1.0)')
    return p.parse_args()


def main():
    args = parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    fs = setup_style(args.fontscale)
    MC = args.min_cohorts

    print("\n[1/5] Loading data...")
    abund, meta = load_data(args.abundance, args.metadata)
    cohorts = sorted(meta['Dataset'].unique())
    K = len(cohorts)
    CC = {c: COHORT_PALETTE[i % len(COHORT_PALETTE)]
          for i, c in enumerate(cohorts)}
    sample_order = list(meta.index)
    species_cols = abund.index.tolist()

    print("[2/5] Computing cohort means...")
    M = pd.DataFrame(index=species_cols, columns=cohorts, dtype=float)
    for c in cohorts:
        samps = [s for s in meta.index if meta.loc[s, 'Dataset'] == c]
        M[c] = abund[samps].mean(axis=1)

    print("[3/5] Running Kneedle analysis...")
    thresholds, curves, knees = run_kneedle(M, x_max=args.kneedle_range)
    ELBOW = round(knees[2].knee, 2)
    ELBOW_Y = curves[2][np.argmin(np.abs(thresholds - ELBOW))]
    print(f"  Elbow (>=2 cohorts) = {ELBOW}%  -> {ELBOW_Y} species")
    n_mc = curves[MC][np.argmin(np.abs(thresholds - ELBOW))]
    print(f"  At elbow, >={MC} cohorts -> {n_mc} species")

    print("[4/5] Filtering species...")
    n_pass = (M >= ELBOW).sum(axis=1)
    retained = sorted(n_pass[n_pass >= MC].index,
                      key=lambda s: -M.loc[s].max())
    filtered_vis = sorted(
        [s for s in species_cols
         if n_pass[s] < MC and (M.loc[s] >= ELBOW).any()],
        key=lambda s: -M.loc[s].max())

    print(f"  Retained: {len(retained)} species (>={MC} cohorts)")
    print(f"  Filtered: {len(filtered_vis)} species")

    max_cohort_mean = M.max(axis=1)
    top_ret = sorted(retained, key=lambda s: -max_cohort_mean[s])[:args.top_n]
    top_filt = sorted(filtered_vis, key=lambda s: -max_cohort_mean[s])[:args.top_n]

    print("\n[5/5] Generating figures...")

    print("  Fig A: Per-cohort abundance distribution")
    df_a = plot_fig_a(M, CC, fs, args.outdir, args.dpi)

    print("  Fig B: Kneedle elbow detection")
    df_b = plot_fig_b(thresholds, curves, knees, ELBOW, ELBOW_Y, MC,
                      fs, args.outdir, args.dpi)

    print("  Fig C: Top retained species stacked bar")
    df_c = plot_fig_c(
        top_ret, abund, meta, sample_order, CC,
        f'Top {args.top_n} retained core species '
        f'(>= {ELBOW}% in >= {MC} cohorts, ranked by max cohort mean)',
        SPECIES_PALETTE, fs, args.outdir,
        'fig_C_retained_stacked_bar', args.dpi)

    print("  Fig D: Top filtered species stacked bar")
    df_d = plot_fig_c(
        top_filt, abund, meta, sample_order, CC,
        f'Top {args.top_n} filtered cohort-specific species '
        f'(>= {ELBOW}% in < {MC} cohorts, ranked by max cohort mean)',
        SPECIES_PALETTE, fs, args.outdir,
        'fig_D_filtered_stacked_bar', args.dpi)

    print("  Fig E: Retained species abundance profile")
    df_e = plot_fig_e(retained, M, abund, ELBOW, MC, fs, args.outdir, args.dpi)

    print("\n  Exporting TSV source data...")
    tsv_files = {
        'fig_A_abundance_distribution': df_a,
        'fig_B_kneedle_curve': df_b,
        'fig_C_retained_stacked_bar': df_c,
        'fig_D_filtered_stacked_bar': df_d,
        'fig_E_retained_profile': df_e,
    }
    for name, df in tsv_files.items():
        tsv_path = os.path.join(args.outdir, f'{name}.tsv')
        df.to_csv(tsv_path, sep='\t', index=False)
        print(f"    saved: {tsv_path}")

    print("  Exporting Excel source data (S_tables.xlsx)...")
    xlsx_path = os.path.join(args.outdir, 'S_tables.xlsx')
    with pd.ExcelWriter(xlsx_path, engine='openpyxl') as writer:
        for sheet_name, df in tsv_files.items():
            df.to_excel(writer, sheet_name=sheet_name[:31], index=False)
    print(f"    saved: {xlsx_path}")

    print(f"\nAll outputs saved to: {args.outdir}/")
    print("Done.\n")


if __name__ == '__main__':
    main()
