python cross_cohort_filter_viz.py \
    --abundance ../input/species.relative.abundance.tsv \
    --metadata ../input/group.tsv \
    --outdir results/ \
    --min-cohorts 2 \
    --top-n 10 \
    --kneedle-range 5.0 \
    --dpi 300 \
    --fontscale 1.0
