Rscript pam.r \
  --abundance ../input/species.relative.abundance.tsv \
  --metadata  ../input/group.tsv \
  --outdir    result \
  --manual_k 4 \
  --pam_k  3

