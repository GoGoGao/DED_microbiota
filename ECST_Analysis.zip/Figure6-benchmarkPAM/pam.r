#!/usr/bin/env Rscript
# Usage:
#   Rscript benchmark.r \
#     --abundance total_relative.xls \
#     --metadata  group.tsv \
#     --outdir    ./output
#
#   Optional arguments:
#     --mean_abd_thr  Per-cohort mean abundance threshold [default: 0.0054]
#     --min_cohorts   Min cohorts a species must pass filter [default: 2]
#     --manual_k      DMM k, set 0 for auto-select [default: 4]
#     --pam_k         PAM k [default: 3]
#     --kmax          Max k for DMM scan [default: 8]
#     --exclude       Cohorts to exclude, comma-separated [default: none]
#     --seed          Random seed [default: 2025]
#
# Outputs (used by ecst_clinical_figure.py):
#   M03_PAM_Validation/silhouette_scan_PAM_vs_DMM.tsv  -> Figure6A
#   M03_PAM_Validation/pcoa_pam_df.tsv                 -> Figure6B
#   M05_PAM_Validation/loco_DMM_vs_PAM.tsv             -> Figure6C
#   M04_PAM_Disease/pam_disease_proportion.tsv          -> Figure6D
#
# Dependencies: MMUPHin, DirichletMultinomial, vegan, cluster,
#               tidyverse, patchwork

suppressPackageStartupMessages(library(optparse))

option_list <- list(
  make_option("--abundance",    type = "character", help = "Kraken2 species abundance table (TSV/XLS, row names: k__XXX|s__Species)"),
  make_option("--metadata",     type = "character", help = "Metadata TSV (columns: Sample/Dataset/Group/SamplingSite/Country)"),
  make_option("--outdir",       type = "character", default = "output",  help = "Output directory [default: output]"),
  make_option("--exclude",      type = "character", default = "",        help = "Cohorts to exclude, comma-separated [default: none]"),
  make_option("--mean_abd_thr", type = "double",    default = 0.0054,    help = "Per-cohort mean abundance threshold [default: 0.0054]"),
  make_option("--min_cohorts",  type = "integer",   default = 2L,        help = "Min cohorts passing threshold to retain a species [default: 2]"),
  make_option("--prev",         type = "double",    default = 0,         help = "Prevalence filter fallback threshold [default: 0]"),
  make_option("--manual_k",     type = "integer",   default = 4L,        help = "DMM k (0 = auto-select) [default: 4]"),
  make_option("--pam_k",        type = "integer",   default = 3L,        help = "PAM k [default: 3]"),
  make_option("--kmax",         type = "integer",   default = 8L,        help = "Max k for DMM scan [default: 8]"),
  make_option("--seed",         type = "integer",   default = 2025L,     help = "Random seed [default: 2025]")
)

opt <- parse_args(OptionParser(option_list = option_list))
if (is.null(opt$abundance) || is.null(opt$metadata))
  stop("--abundance and --metadata are required")

ABUNDANCE_FILE   <- opt$abundance
METADATA_FILE    <- opt$metadata
BASE_OUT         <- opt$outdir
EXCLUDED_COHORTS <- if (nchar(opt$exclude) > 0) strsplit(opt$exclude, ",")[[1]] else character(0)
MEAN_ABD_THR     <- opt$mean_abd_thr
MIN_COHORTS      <- opt$min_cohorts
PREV_THR         <- opt$prev
MANUAL_K         <- if (opt$manual_k == 0L) NULL else opt$manual_k
PAM_K            <- opt$pam_k
K_MAX            <- opt$kmax
SEED             <- opt$seed
ABD_THR          <- 1e-5
PSEUDO           <- 1e-5

if (!is.null(MANUAL_K) && (MANUAL_K < 2 || MANUAL_K > K_MAX))
  stop(sprintf("--manual_k must be between 2 and %d, got: %d", K_MAX, MANUAL_K))
if (PAM_K < 2 || PAM_K > K_MAX)
  stop(sprintf("--pam_k must be between 2 and %d, got: %d", K_MAX, PAM_K))

cat("============================================\n")
cat("ECST Pipeline\n")
cat("  abundance    :", ABUNDANCE_FILE, "\n")
cat("  metadata     :", METADATA_FILE, "\n")
cat("  outdir       :", BASE_OUT, "\n")
cat("  exclude      :", ifelse(length(EXCLUDED_COHORTS) > 0,
    paste(EXCLUDED_COHORTS, collapse = ","), "(none)"), "\n")
cat("  mean_abd_thr :", MEAN_ABD_THR * 100, "%\n")
cat("  min_cohorts  :", MIN_COHORTS, "\n")
cat("  DMM k        :", ifelse(is.null(MANUAL_K), "auto", MANUAL_K), "\n")
cat("  PAM k        :", PAM_K, "\n")
cat("  kmax         :", K_MAX, "\n")
cat("  seed         :", SEED, "\n")
cat("============================================\n\n")

suppressPackageStartupMessages({
  library(MMUPHin); library(DirichletMultinomial)
  library(vegan); library(cluster)
  library(tidyverse); library(patchwork); library(ggrepel)
})

if ("package:plyr" %in% search())
  detach("package:plyr", unload = FALSE, force = TRUE)
library(dplyr, warn.conflicts = FALSE)

make_outdir <- function(m) {
  d <- file.path(BASE_OUT, m)
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
  d
}

save_tsv <- function(df, path) {
  write.table(df, paste0(path, ".tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
}

save_fig <- function(p, path, w = 180, h = 120) {
  ggsave(paste0(path, ".pdf"), p, width = w, height = h, units = "mm", dpi = 300)
  ggsave(paste0(path, ".png"), p, width = w, height = h, units = "mm", dpi = 300)
  cat("  Figure:", basename(path), "\n")
}

CNS_THEME <- theme_classic(base_size = 7) +
  theme(
    axis.line        = element_line(linewidth = 0.3, color = "black"),
    axis.ticks       = element_line(linewidth = 0.2, color = "black"),
    axis.text        = element_text(size = 6, color = "black"),
    axis.title       = element_text(size = 7, color = "black"),
    legend.text      = element_text(size = 5.5),
    legend.title     = element_text(size = 6.5, face = "bold"),
    legend.key.size  = unit(2.5, "mm"),
    legend.background = element_rect(fill = "white", color = NA),
    strip.text       = element_text(size = 6.5, face = "bold"),
    strip.background = element_blank(),
    panel.grid       = element_blank(),
    plot.title       = element_text(size = 8, face = "bold", hjust = 0),
    plot.subtitle    = element_text(size = 6, face = "italic"),
    plot.margin      = margin(3, 3, 3, 3, "pt")
  )

to_proportion <- function(mat) {
  mat[mat < 0] <- 0
  cs <- colSums(mat); cs[cs == 0] <- 1
  sweep(mat, 2, cs, "/")
}

clr_transform <- function(mat) {
  mat[mat < 0] <- 0
  m <- mat + PSEUDO
  apply(m, 2, function(x) log(x) - mean(log(x)))
}

ari <- function(a, b) {
  tab <- table(a, b); n <- sum(tab)
  ai  <- rowSums(tab); bj <- colSums(tab)
  sum_cij2 <- sum(choose(tab, 2))
  sum_ai2  <- sum(choose(ai, 2)); sum_bj2 <- sum(choose(bj, 2))
  en  <- sum_ai2 * sum_bj2 / choose(n, 2)
  num <- sum_cij2 - en; den <- (sum_ai2 + sum_bj2) / 2 - en
  if (den == 0) return(1); num / den
}

nmi <- function(a, b) {
  tab <- table(a, b); n <- sum(tab)
  pi  <- rowSums(tab) / n; pj <- colSums(tab) / n
  h_a <- -sum(pi[pi > 0] * log(pi[pi > 0]))
  h_b <- -sum(pj[pj > 0] * log(pj[pj > 0]))
  mi  <- 0
  for (i in 1:nrow(tab))
    for (j in 1:ncol(tab))
      if (tab[i, j] > 0)
        mi <- mi + tab[i, j] / n * log(tab[i, j] / n / (pi[i] * pj[j]))
  if ((h_a + h_b) == 0) return(1); 2 * mi / (h_a + h_b)
}

ECST_PAL <- c("#E64B35", "#4DBBD5", "#00A087", "#3C5488",
              "#F39B7F", "#8491B4", "#91D1C2", "#7E6148")

# ====================================================================
# M01 — MMUPHin batch correction
# ====================================================================
cat("\n=== M01: MMUPHin Batch Correction ===\n")
OUT_M01 <- make_outdir("M01_MMUPHin")

species_raw <- read.table(ABUNDANCE_FILE, sep = "\t", header = TRUE,
                          row.names = 1, check.names = FALSE)
meta_raw    <- read.table(METADATA_FILE,  sep = "\t", header = TRUE, check.names = FALSE)

if (length(EXCLUDED_COHORTS) > 0) {
  meta_raw <- meta_raw[!meta_raw$Dataset %in% EXCLUDED_COHORTS, ]
  cat("  Excluded cohorts:", paste(EXCLUDED_COHORTS, collapse = ", "), "\n")
} else {
  cat("  All cohorts retained\n")
}

original_names <- rownames(species_raw)
parsed_names <- sapply(original_names, function(nm) {
  m <- regmatches(nm, regexpr("s__[^|]+", nm))
  if (length(m) > 0) sub("^s__", "", m) else nm
})
if (any(duplicated(parsed_names))) {
  cat("  Warning:", sum(duplicated(parsed_names)), "duplicate species names, merging\n")
  species_raw <- as.data.frame(species_raw)
  species_raw$sp_parsed <- parsed_names
  species_raw <- species_raw %>%
    group_by(sp_parsed) %>%
    summarise(across(everything(), sum)) %>%
    column_to_rownames("sp_parsed")
} else {
  rownames(species_raw) <- parsed_names
}
cat("  Species parsed:", length(original_names), "->", nrow(species_raw), "\n")

common  <- intersect(colnames(species_raw), meta_raw$Sample)
species <- species_raw[, common]
meta    <- meta_raw[match(common, meta_raw$Sample), ]
rownames(meta) <- meta$Sample
meta$Cohort    <- meta$Dataset
cat("  Samples:", length(common), "| Species:", nrow(species), "\n")

cat("  Cross-cohort consistency filter (mean >=",
    MEAN_ABD_THR * 100, "%, cohorts >=", MIN_COHORTS, ")...\n")
species_prop    <- to_proportion(species)
cohort_list     <- unique(meta$Cohort)
cohort_mean_mat <- matrix(0, nrow = nrow(species_prop), ncol = length(cohort_list),
                          dimnames = list(rownames(species_prop), cohort_list))
for (coh in cohort_list) {
  samps <- intersect(meta$Sample[meta$Cohort == coh], colnames(species_prop))
  if (length(samps) > 0)
    cohort_mean_mat[, coh] <- rowMeans(species_prop[, samps, drop = FALSE])
}
cohort_pass  <- apply(cohort_mean_mat, 1, function(x) sum(x >= MEAN_ABD_THR))
species_keep <- names(cohort_pass[cohort_pass >= MIN_COHORTS])

if (length(species_keep) < 3) {
  cat("  Warning: too few species after filter, falling back to prevalence filter\n")
  prev         <- apply(species_prop, 1, function(x) mean(x > ABD_THR))
  species_filt <- to_proportion(species_prop[prev >= PREV_THR, , drop = FALSE])
} else {
  species_filt <- to_proportion(species_prop[species_keep, , drop = FALSE])
  cat("  Species retained:", length(species_keep), "\n")
}

gpc <- tapply(meta$Group, meta$Cohort, function(x) length(unique(x)))
if (any(gpc <= 1)) {
  fit <- adjust_batch(feature_abd = species_filt, batch = "Cohort",
                      data = meta[colnames(species_filt), ],
                      control = list(verbose = FALSE))
} else {
  fit <- adjust_batch(feature_abd = species_filt, batch = "Cohort", covariates = "Group",
                      data = meta[colnames(species_filt), ],
                      control = list(verbose = FALSE))
}
corrected              <- fit$feature_abd_adj
corrected[corrected < 0] <- 0
corrected              <- to_proportion(corrected)
write.table(corrected, file.path(OUT_M01, "abundance_corrected.tsv"),
            sep = "\t", quote = FALSE)
cat("  Batch correction done\n")

# ====================================================================
# M02 — DMM clustering
# ====================================================================
cat("\n=== M02: DMM Clustering ===\n")
OUT_M02 <- make_outdir("M02_DMM")

abd   <- corrected
SCALE <- 10000
count_mat <- round(t(abd) * SCALE)
count_mat <- count_mat[, colSums(count_mat) > 0, drop = FALSE]
count_mat <- count_mat[rowSums(count_mat) > 0, , drop = FALSE]
cat("  Count matrix:", nrow(count_mat), "x", ncol(count_mat), "\n")

set.seed(SEED)
fit_list <- lapply(1:K_MAX, function(k) {
  cat("  k =", k, "...")
  f <- dmn(count_mat, k = k, verbose = FALSE)
  cat(" Laplace =", round(laplace(f)), "\n")
  f
})

laps <- sapply(fit_list, laplace)

bc_dmm <- vegdist(count_mat, method = "bray")
bc_mat <- as.matrix(bc_dmm); bc_mat[is.nan(bc_mat)] <- 0; bc_dmm <- as.dist(bc_mat)

sil_scan <- sapply(2:K_MAX, function(k) {
  a <- apply(mixture(fit_list[[k]]), 1, which.max)
  mean(silhouette(a, dist = bc_dmm)[, "sil_width"])
})
names(sil_scan) <- 2:K_MAX
sil_scan_df <- data.frame(k = 2:K_MAX, avg_sil = sil_scan)

sil_top3   <- sort(sil_scan, decreasing = TRUE)[1:min(3, length(sil_scan))]
candidates <- as.integer(names(sil_top3))
auto_k     <- candidates[which.min(laps[candidates])]

if (!is.null(MANUAL_K)) {
  optimal_k <- MANUAL_K
  cat(sprintf("  Manual override: k=%d\n", optimal_k))
} else {
  optimal_k <- auto_k
  cat(sprintf("  Auto-selected: k=%d (Sil=%.3f)\n", auto_k, sil_scan[as.character(auto_k)]))
}

best_fit    <- fit_list[[optimal_k]]
post_probs  <- mixture(best_fit)
ecst_assign <- apply(post_probs, 1, which.max)

ecst_df <- data.frame(
  sample_id      = rownames(count_mat),
  ECST           = paste0("ECST_", ecst_assign),
  posterior_prob = round(apply(post_probs, 1, max), 4),
  stringsAsFactors = FALSE
) %>% left_join(meta, by = c("sample_id" = "Sample"))
cat("  ECST distribution:\n"); print(table(ecst_df$ECST))

sil     <- silhouette(ecst_assign, dist = bc_dmm)
avg_sil <- mean(sil[, "sil_width"])
sil_df  <- data.frame(ECST      = paste0("ECST_", sil[, "cluster"]),
                       sil_width = sil[, "sil_width"])

save_tsv(ecst_df,  file.path(OUT_M02, "ecst_assignment"))
saveRDS(fit_list,  file.path(OUT_M02, "dmm_fit_list.rds"))

abd  <- abd[, colnames(abd) %in% ecst_df$sample_id, drop = FALSE]
meta <- meta[rownames(meta) %in% ecst_df$sample_id, ]

# ====================================================================
# M03 — PAM clustering validation
# Outputs: silhouette_scan_PAM_vs_DMM.tsv (Figure6A)
#          pcoa_pam_df.tsv                (Figure6B)
# ====================================================================
cat("\n=== M03: PAM Clustering Validation ===\n")
OUT_M03 <- make_outdir("M03_PAM_Validation")

abd_pam  <- abd[, colSums(abd) > 0, drop = FALSE]
bc_pam   <- vegdist(t(abd_pam), method = "bray")
bc_pam_m <- as.matrix(bc_pam); bc_pam_m[is.nan(bc_pam_m)] <- 0
bc_pam   <- as.dist(bc_pam_m)

set.seed(SEED)
pam_fit    <- pam(bc_pam, k = PAM_K, diss = TRUE)
pam_assign <- paste0("PAM_", pam_fit$clustering)
names(pam_assign) <- names(pam_fit$clustering)

pam_sil     <- silhouette(pam_fit$clustering, dist = bc_pam)
pam_avg_sil <- mean(pam_sil[, "sil_width"])
cat(sprintf("  PAM (k=%d): Avg Sil=%.3f  |  DMM (k=%d): Avg Sil=%.3f\n",
            PAM_K, pam_avg_sil, optimal_k, avg_sil))

pam_sil_scan <- sapply(2:K_MAX, function(k) {
  set.seed(SEED)
  pf <- pam(bc_pam, k = k, diss = TRUE)
  mean(silhouette(pf$clustering, dist = bc_pam)[, "sil_width"])
})
names(pam_sil_scan) <- 2:K_MAX
pam_sil_df <- data.frame(k = 2:K_MAX, avg_sil_PAM = pam_sil_scan)
pam_sil_df$avg_sil_DMM <- sil_scan_df$avg_sil[match(pam_sil_df$k, sil_scan_df$k)]
save_tsv(pam_sil_df, file.path(OUT_M03, "silhouette_scan_PAM_vs_DMM"))
cat("  Saved: silhouette_scan_PAM_vs_DMM.tsv\n")

sil_long <- pam_sil_df %>%
  pivot_longer(c(avg_sil_PAM, avg_sil_DMM), names_to = "method", values_to = "avg_sil") %>%
  mutate(method = gsub("avg_sil_", "", method))

p_A <- ggplot(sil_long, aes(k, avg_sil, color = method, shape = method)) +
  geom_line(linewidth = 0.5) +
  geom_point(size = 2) +
  geom_point(data = sil_long[sil_long$k == optimal_k & sil_long$method == "DMM", ],
             size = 3.5, shape = 18, color = "#3C5488", show.legend = FALSE) +
  geom_point(data = sil_long[sil_long$k == PAM_K & sil_long$method == "PAM", ],
             size = 3.5, shape = 18, color = "#E64B35", show.legend = FALSE) +
  geom_hline(yintercept = 0.5, linetype = "dashed", linewidth = 0.2, color = "grey60") +
  annotate("text", x = PAM_K,    y = max(sil_long$avg_sil, na.rm = TRUE) * 0.97,
           label = sprintf("PAM k=%d", PAM_K),    size = 2.2, fontface = "bold", color = "#E64B35") +
  annotate("text", x = optimal_k, y = max(sil_long$avg_sil, na.rm = TRUE) * 0.87,
           label = sprintf("DMM k=%d", optimal_k), size = 2.2, fontface = "bold", color = "#3C5488") +
  scale_color_manual(values = c("PAM" = "#E64B35", "DMM" = "#3C5488"), name = "Method") +
  scale_shape_manual(values = c("PAM" = 16, "DMM" = 17), name = "Method") +
  scale_x_continuous(breaks = 2:K_MAX) +
  labs(x = "Number of clusters (k)", y = "Average Silhouette width",
       title = "Silhouette comparison") +
  CNS_THEME
save_fig(p_A, file.path(OUT_M03, "Figure6A_Silhouette"), w = 100, h = 70)

common_samps_pam <- intersect(names(pam_assign), ecst_df$sample_id)
dmm_labels_pam   <- setNames(ecst_df$ECST, ecst_df$sample_id)[common_samps_pam]
pam_labels_pam   <- pam_assign[common_samps_pam]

cross_tab   <- table(PAM = pam_labels_pam, DMM = dmm_labels_pam)
pam_to_ecst <- setNames(
  apply(cross_tab, 1, function(row) colnames(cross_tab)[which.max(row)]),
  rownames(cross_tab))
pam_mapped   <- pam_to_ecst[pam_labels_pam]
accuracy_pam <- mean(pam_mapped == dmm_labels_pam)
ari_pam      <- ari(dmm_labels_pam, pam_labels_pam)
nmi_pam      <- nmi(dmm_labels_pam, pam_labels_pam)
cat(sprintf("  PAM vs DMM: ARI=%.3f | NMI=%.3f | Accuracy=%.3f\n",
            ari_pam, nmi_pam, accuracy_pam))

pam_df <- data.frame(
  sample_id       = common_samps_pam,
  ECST_DMM        = as.character(dmm_labels_pam),
  PAM_cluster     = as.character(pam_labels_pam),
  PAM_mapped_ECST = as.character(pam_mapped),
  concordant      = (pam_mapped == dmm_labels_pam),
  stringsAsFactors = FALSE
) %>% left_join(ecst_df[, c("sample_id", "Dataset", "Group")], by = "sample_id")
save_tsv(pam_df, file.path(OUT_M03, "pam_assignment"))

pcoa_pam_r  <- cmdscale(bc_pam, k = 2, eig = TRUE)
ve_pam      <- round(pcoa_pam_r$eig[1:2] / sum(abs(pcoa_pam_r$eig)) * 100, 1)
pcoa_pam_df <- data.frame(
  sample_id = labels(bc_pam),
  PC1       = pcoa_pam_r$points[, 1],
  PC2       = pcoa_pam_r$points[, 2],
  ve1       = ve_pam[1],
  ve2       = ve_pam[2],
  stringsAsFactors = FALSE
) %>% left_join(pam_df[, c("sample_id", "PAM_cluster")], by = "sample_id")
save_tsv(pcoa_pam_df, file.path(OUT_M03, "pcoa_pam_df"))
cat("  Saved: pcoa_pam_df.tsv\n")

PAM_COLORS <- setNames(ECST_PAL[1:PAM_K], paste0("PAM_", 1:PAM_K))

hull_pam <- pcoa_pam_df %>%
  filter(!is.na(PAM_cluster)) %>%
  group_by(PAM_cluster) %>%
  slice(chull(PC1, PC2)) %>%
  ungroup()

p_B <- ggplot(pcoa_pam_df, aes(PC1, PC2)) +
  geom_polygon(data = hull_pam, aes(fill = PAM_cluster), alpha = 0.10, color = NA) +
  geom_point(aes(color = PAM_cluster), size = 1, alpha = 0.7) +
  scale_color_manual(values = PAM_COLORS, name = NULL) +
  scale_fill_manual(values  = PAM_COLORS, guide = "none") +
  labs(x = paste0("PCoA1 (", ve_pam[1], "%)"),
       y = paste0("PCoA2 (", ve_pam[2], "%)"),
       title = sprintf("PAM Cluster (k=%d)", PAM_K)) +
  CNS_THEME +
  theme(legend.position = "right")
save_fig(p_B, file.path(OUT_M03, "Figure6B_PCoA_PAM"), w = 100, h = 85)

concordance <- data.frame(
  metric = c("ARI", "NMI", "Accuracy", "DMM_avg_sil", "PAM_avg_sil"),
  value  = c(ari_pam, nmi_pam, accuracy_pam, avg_sil, pam_avg_sil))
save_tsv(concordance, file.path(OUT_M03, "dmm_vs_pam_concordance"))

# ====================================================================
# M04 — PAM disease association (Panel D)
# Outputs: pam_disease_proportion.tsv (Figure6D)
# ====================================================================
cat("\n=== M04: PAM Disease Association ===\n")
OUT_M04 <- make_outdir("M04_PAM_Disease")

disease_cohorts <- ecst_df %>%
  filter(!is.na(ECST) & !is.na(Group) & Group != "Unknown") %>%
  group_by(Dataset) %>%
  summarise(has_ctrl = "Control" %in% Group,
            has_dis  = any(!Group %in% c("Control", "Unknown")),
            n_ctrl   = sum(Group == "Control"),
            n_dis    = sum(!Group %in% c("Control", "Unknown")),
            .groups  = "drop") %>%
  filter(has_ctrl & has_dis & n_ctrl >= 3 & n_dis >= 3) %>%
  pull(Dataset)
cat("  Disease cohorts:", paste(disease_cohorts, collapse = ", "), "\n")

ecst_df_pam <- ecst_df %>%
  left_join(pam_df[, c("sample_id", "PAM_cluster", "PAM_mapped_ECST", "concordant")],
            by = "sample_id") %>%
  filter(!is.na(PAM_cluster))
ecst_df_pam$ECST_PAM <- gsub("^PAM_", "PECST_", ecst_df_pam$PAM_cluster)

PECST_COLORS <- setNames(
  c("#E8723A", "#2CA8C2", "#5AAE61", "#9673B9",
    "#F4A460", "#8B8989", "#CD6889", "#8DB6CD")[1:PAM_K],
  paste0("PECST_", 1:PAM_K))

if (length(disease_cohorts) == 0) {
  cat("  No disease cohorts found, skipping Panel D table\n")
} else {
  ecst_dis_pam <- ecst_df_pam %>%
    filter(Dataset %in% disease_cohorts & Group != "Unknown" & !is.na(ECST_PAM))

  fisher_per_cohort_pam <- list()
  for (coh in disease_cohorts) {
    sub   <- ecst_dis_pam %>% filter(Dataset == coh)
    dis   <- setdiff(unique(sub$Group), "Control")
    if (length(dis) == 0 || !"Control" %in% sub$Group) next
    cross <- table(sub$Group, sub$ECST_PAM)
    cross <- cross[, colSums(cross) > 0, drop = FALSE]
    if (nrow(cross) < 2) next
    ft    <- fisher.test(cross, simulate.p.value = TRUE, B = 10000)
    fisher_per_cohort_pam[[coh]] <- data.frame(
      cohort = coh, fisher_p = ft$p.value, stringsAsFactors = FALSE)
    cat(sprintf("  %s: Fisher P = %.3e\n", coh, ft$p.value))
  }
  save_tsv(bind_rows(fisher_per_cohort_pam),
           file.path(OUT_M04, "fisher_per_cohort_pam"))

  prop_dis_pam <- ecst_dis_pam %>%
    dplyr::count(Dataset, Group, ECST_PAM) %>%
    group_by(Dataset, Group) %>%
    mutate(prop = n / sum(n)) %>%
    ungroup()
  save_tsv(prop_dis_pam, file.path(OUT_M04, "pam_disease_proportion"))
  cat("  Saved: pam_disease_proportion.tsv\n")

  fisher_df  <- bind_rows(fisher_per_cohort_pam)
  facet_labs <- setNames(
    sprintf("%s\nFisher P = %.2e", fisher_df$cohort, fisher_df$fisher_p),
    fisher_df$cohort)

  p_D <- ggplot(prop_dis_pam, aes(x = Group, y = prop, fill = ECST_PAM)) +
    geom_bar(stat = "identity", width = 0.6, color = "white", linewidth = 0.2) +
    facet_wrap(~ Dataset, scales = "free_x",
               labeller = labeller(Dataset = facet_labs)) +
    scale_fill_manual(values = PECST_COLORS, name = "PAM ECST") +
    scale_y_continuous(labels = scales::percent,
                       expand = expansion(mult = c(0, 0.05))) +
    labs(x = NULL, y = "Proportion", title = "PAM-based ECST \u00d7 Disease") +
    CNS_THEME +
    theme(axis.text.x  = element_text(angle = 45, hjust = 1, size = 5),
          strip.text   = element_text(size = 5.5, face = "bold", lineheight = 1.2))
  save_fig(p_D, file.path(OUT_M04, "Figure6D_Disease_Proportion"), w = 160, h = 80)
}

# ====================================================================
# M05 — PAM LOCO cross-validation (Panel C)
# Outputs: loco_DMM_vs_PAM.tsv (Figure6C)
# ====================================================================
cat("\n=== M05: PAM LOCO Cross-Validation ===\n")
OUT_M05 <- make_outdir("M05_PAM_Validation")

cohorts        <- unique(ecst_df$Dataset)
ref_labels     <- setNames(ecst_df$ECST,      ecst_df$sample_id)
ref_labels_pam <- setNames(ecst_df_pam$ECST_PAM, ecst_df_pam$sample_id)

loco_results     <- list()
loco_results_pam <- list()

for (leave_out in cohorts) {
  cat(sprintf("  LOCO: removing %s ...", leave_out))
  keep_samps <- ecst_df$sample_id[ecst_df$Dataset != leave_out]
  keep_samps <- keep_samps[keep_samps %in% colnames(abd)]
  if (length(keep_samps) < 20) { cat(" too few, skip\n"); next }

  abd_loco <- abd[, keep_samps, drop = FALSE]
  abd_loco <- abd_loco[rowSums(abd_loco) > 0, , drop = FALSE]

  count_loco <- round(t(abd_loco) * SCALE)
  count_loco <- count_loco[rowSums(count_loco) > 0, colSums(count_loco) > 0, drop = FALSE]

  set.seed(SEED)
  fit_loco <- tryCatch(dmn(count_loco, k = optimal_k, verbose = FALSE),
                       error = function(e) NULL)
  if (!is.null(fit_loco)) {
    loco_assign  <- paste0("ECST_", apply(mixture(fit_loco), 1, which.max))
    names(loco_assign) <- rownames(count_loco)
    cs_dmm  <- intersect(names(loco_assign), names(ref_labels))
    ari_dmm <- ari(ref_labels[cs_dmm], loco_assign[cs_dmm])
    nmi_dmm <- nmi(ref_labels[cs_dmm], loco_assign[cs_dmm])
    loco_results[[leave_out]] <- data.frame(
      left_out = leave_out, ARI = ari_dmm, NMI = nmi_dmm,
      method = "DMM", stringsAsFactors = FALSE)
    cat(sprintf(" DMM ARI=%.3f", ari_dmm))
  }

  bc_loco   <- vegdist(t(abd_loco), method = "bray")
  bc_loco_m <- as.matrix(bc_loco); bc_loco_m[is.nan(bc_loco_m)] <- 0
  bc_loco   <- as.dist(bc_loco_m)
  set.seed(SEED)
  pam_loco <- tryCatch(pam(bc_loco, k = PAM_K, diss = TRUE),
                       error = function(e) NULL)
  if (!is.null(pam_loco)) {
    loco_raw <- paste0("PAM_", pam_loco$clustering)
    names(loco_raw) <- names(pam_loco$clustering)
    cs_pam   <- intersect(names(loco_raw), names(ref_labels_pam))
    if (length(cs_pam) >= 10) {
      ct_map   <- table(loco_raw[cs_pam], ref_labels_pam[cs_pam])
      loco_map <- setNames(
        apply(ct_map, 1, function(row) colnames(ct_map)[which.max(row)]),
        rownames(ct_map))
      loco_mapped <- loco_map[loco_raw[cs_pam]]
      ari_pam_loco <- ari(ref_labels_pam[cs_pam], loco_mapped)
      nmi_pam_loco <- nmi(ref_labels_pam[cs_pam], loco_mapped)
      loco_results_pam[[leave_out]] <- data.frame(
        left_out = leave_out, ARI = ari_pam_loco, NMI = nmi_pam_loco,
        method = "PAM", stringsAsFactors = FALSE)
      cat(sprintf(" PAM ARI=%.3f", ari_pam_loco))
    }
  }
  cat("\n")
}

loco_df     <- bind_rows(loco_results)
loco_df_pam <- bind_rows(loco_results_pam)
loco_compare <- bind_rows(
  loco_df     %>% select(left_out, ARI, NMI, method),
  loco_df_pam %>% select(left_out, ARI, NMI, method))
save_tsv(loco_compare, file.path(OUT_M05, "loco_DMM_vs_PAM"))
cat("  Saved: loco_DMM_vs_PAM.tsv\n")

dmm_v <- loco_compare$ARI[loco_compare$method == "DMM"]
pam_v <- loco_compare$ARI[loco_compare$method == "PAM"]
wt_p <- tryCatch({
  if (length(dmm_v) >= 3 && length(pam_v) >= 3)
    wilcox.test(dmm_v, pam_v, paired = TRUE)$p.value
  else
    NA_real_
}, error = function(e) NA_real_)

p_C <- ggplot(loco_compare, aes(x = method, y = ARI, fill = method)) +
  geom_boxplot(width = 0.4, outlier.shape = NA, alpha = 0.5,
               linewidth = 0.5, color = "black") +
  geom_jitter(aes(color = method), width = 0.08, size = 1.5, alpha = 0.8) +
  geom_hline(yintercept = 0.5, linetype = "dashed", linewidth = 0.4, color = "grey60") +
  scale_fill_manual(values  = c("DMM" = "#3C5488", "PAM" = "#E64B35"), guide = "none") +
  scale_color_manual(values = c("DMM" = "#3C5488", "PAM" = "#E64B35"), guide = "none") +
  annotate("text", x = 1.5, y = max(loco_compare$ARI, na.rm = TRUE) * 1.02,
           label = if (!is.na(wt_p)) sprintf("Wilcoxon, p = %.2f", wt_p) else "",
           size = 2.2, hjust = 0.5) +
  annotate("text", x = 1.5, y = 0.52,
           label = sprintf("DMM mean=%.3f | PAM mean=%.3f",
                           mean(dmm_v, na.rm = TRUE), mean(pam_v, na.rm = TRUE)),
           size = 1.9, color = "#555", hjust = 0.5) +
  labs(x = NULL, y = "LOCO ARI", title = "") +
  CNS_THEME
save_fig(p_C, file.path(OUT_M05, "Figure6C_LOCO_ARI"), w = 70, h = 85)

# ====================================================================
# Summary
# ====================================================================
cat("\n============================================\n")
cat("Pipeline complete\n")
cat("  Output directory:", BASE_OUT, "\n")
cat(sprintf("  DMM k=%d  Avg Sil=%.3f\n", optimal_k, avg_sil))
cat(sprintf("  PAM k=%d  Avg Sil=%.3f\n", PAM_K, pam_avg_sil))
cat(sprintf("  PAM vs DMM: ARI=%.3f | NMI=%.3f\n", ari_pam, nmi_pam))
cat(sprintf("  LOCO DMM mean ARI=%.3f | PAM mean ARI=%.3f\n",
            mean(loco_df$ARI), mean(loco_df_pam$ARI)))
cat("\nOutputs for ecst_clinical_figure.py:\n")
cat("  --sil_tsv    ", file.path(OUT_M03, "silhouette_scan_PAM_vs_DMM.tsv"), "\n")
cat("  --pcoa_tsv   ", file.path(OUT_M03, "pcoa_pam_df.tsv"), "\n")
cat("  --loco_tsv   ", file.path(OUT_M05, "loco_DMM_vs_PAM.tsv"), "\n")
cat("  --disease_tsv", file.path(OUT_M04, "pam_disease_proportion.tsv"), "\n")
cat("============================================\n")
