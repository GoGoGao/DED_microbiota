#!/usr/bin/env python3
"""
Usage:
    python ecst_clinical_figure.py --input clinical.tsv --outdir ./output

Outputs Figure 5C–J (PDF, JPG, SVG) and supplementary TSV/Excel tables.
"""

import argparse, os
import pandas as pd, numpy as np, matplotlib, warnings
warnings.filterwarnings('ignore')
matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype'] = 42
matplotlib.rcParams['svg.fonttype'] = 'none'
import matplotlib.pyplot as plt
from scipy import stats
from scipy.stats import sem

ECST_COLORS = {
    'ECST_1': '#C44E4B',
    'ECST_2': '#45B5C8',
    'ECST_3': '#259982',
    'ECST_4': '#375183',
}
ECST_ORDER = ['ECST_1', 'ECST_2', 'ECST_3', 'ECST_4']
TRAJ_COLORS = {'1→3→4': '#C44E4B', '1→3→2': '#375183'}


def set_rcparams():
    plt.rcParams.update({
        'font.family': 'Times New Roman',
        'font.size': 28,
        'axes.linewidth': 1.2,
        'xtick.major.width': 1.2,
        'ytick.major.width': 1.2,
        'xtick.major.size': 6,
        'ytick.major.size': 6,
        'axes.labelsize': 30,
        'axes.titlesize': 32,
        'legend.fontsize': 22,
        'legend.frameon': False,
        'figure.dpi': 300,
        'axes.spines.top': False,
        'axes.spines.right': False,
    })


def load_data(path):
    df = pd.read_csv(path, sep='\t')
    df['TBUT_num'] = df['TBUT (s)'].replace({'30+': '30', '＜1': '0.5'}).astype(float)
    df[['MGL_upper', 'MGL_lower']] = (
        df['#meibomianglandloss（Upper,Lower）'].str.split(',', expand=True).astype(int))
    df['MGL_total'] = df['MGL_upper'] + df['MGL_lower']
    df['MGD_grade_num'] = df['MGD_grade'].replace({'-': 0}).astype(int)
    df.rename(columns={'Tear_meniscus_height, TMH（mm）': 'TMH'}, inplace=True)
    return df


def save_fig(fig, outdir, name):
    fig.savefig(f'{outdir}/{name}.pdf', dpi=300, bbox_inches='tight')
    fig.savefig(f'{outdir}/{name}.jpg', dpi=400, bbox_inches='tight')
    fig.savefig(f'{outdir}/{name}.svg', bbox_inches='tight')


def add_bracket(ax, x1, x2, y, p, fs=20):
    rng = ax.get_ylim()[1] - ax.get_ylim()[0]
    bh = 0.012 * rng
    ax.plot([x1, x1, x2, x2], [y, y+bh, y+bh, y], lw=1.0, c='#333', clip_on=False)
    txt = '***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else 'ns'
    ax.text((x1+x2)/2, y+bh+0.004*rng, txt, ha='center', va='bottom',
            fontsize=fs, color='#333', fontweight='bold')


def bar_plot(ax, df, var, ylabel, show_brackets=None):
    ns = {e: len(df[df['ECST']==e]) for e in ECST_ORDER}
    pos = np.arange(len(ECST_ORDER))
    groups = [df[df['ECST']==e][var].dropna().values for e in ECST_ORDER]
    means = [np.mean(g) for g in groups]
    sems = [sem(g) for g in groups]

    ax.bar(pos, means, width=0.56,
           color=[ECST_COLORS[e] for e in ECST_ORDER],
           edgecolor=[ECST_COLORS[e] for e in ECST_ORDER],
           linewidth=1.5, zorder=2)
    ax.errorbar(pos, means, yerr=sems, fmt='none',
                ecolor='#444', elinewidth=1.5, capsize=6, capthick=1.5, zorder=3)

    ax.set_xticks(pos)
    ax.set_xticklabels([f'{e}\n(n={ns[e]})' for e in ECST_ORDER], fontsize=20)
    ax.set_ylabel(ylabel)

    valid = [g for g in groups if len(g) >= 2]
    pkw = stats.kruskal(*valid).pvalue
    ax.text(0.97, 0.96, f'Kruskal–Wallis\nP = {pkw:.4f}', transform=ax.transAxes,
            ha='right', va='top', fontsize=18,
            bbox=dict(facecolor='white', edgecolor='#ddd', boxstyle='round,pad=0.3', lw=0.5))

    if show_brackets:
        all_v = np.concatenate(groups)
        yt = all_v.max(); yr = yt - all_v.min()
        for bi, (i1, i2) in enumerate(show_brackets):
            _, p_pw = stats.mannwhitneyu(groups[i1], groups[i2], alternative='two-sided')
            add_bracket(ax, i1, i2, yt + 0.10*yr + bi*0.14*yr, p_pw)
    return groups


def make_panel_c(ax, df):
    radar_config = [
        ('MGD_grade_num', 'MGD grade',  False),
        ('MGL_total',     'MG loss',    False),
        ('McMonnies_Questionnaire', 'McMonnies', False),
        ('TBUT_num',      'TBUT ↓',    True),
        ('Age',           'Age',        False),
        ('OSDI',          'OSDI',       False),
    ]
    rv = [c[0] for c in radar_config]
    rl = [c[1] for c in radar_config]
    ri = [c[2] for c in radar_config]

    med_all = {}
    for vi, var in enumerate(rv):
        vals = df[var].dropna()
        vmin, vmax = vals.min(), vals.max()
        for ecst in ECST_ORDER:
            m = df[df['ECST']==ecst][var].dropna().median()
            n = (m - vmin)/(vmax - vmin) if vmax > vmin else 0.5
            if ri[vi]: n = 1.0 - n
            med_all.setdefault(ecst, []).append(n)

    angles = np.linspace(0, 2*np.pi, len(rv), endpoint=False).tolist() + \
             [np.linspace(0, 2*np.pi, len(rv), endpoint=False)[0]]

    ax.set_theta_offset(np.pi/2); ax.set_theta_direction(-1)
    ax.set_rlabel_position(30)
    ax.spines['polar'].set_linewidth(0.5); ax.spines['polar'].set_color('#ccc')
    ax.tick_params(axis='both', labelsize=20, pad=8)
    ax.set_yticks([0.25, 0.5, 0.75, 1.0])
    ax.set_yticklabels(['', '0.50', '', '1.00'], fontsize=16, color='#bbb')
    ax.set_ylim(0, 1.15); ax.set_xticks(angles[:-1])
    ax.set_xticklabels(rl, fontsize=22)
    ax.grid(color='#e5e5e5', linewidth=0.5)

    for ecst in ECST_ORDER:
        v = med_all[ecst] + med_all[ecst][:1]
        ax.plot(angles, v, lw=2.5, color=ECST_COLORS[ecst], label=ecst, zorder=3,
                marker='o', markersize=7, markeredgecolor='white', markeredgewidth=0.7)
        ax.fill(angles, v, color=ECST_COLORS[ecst], alpha=0.06)

    return med_all


def make_figure5C(df, outdir):
    fig, ax = plt.subplots(figsize=(12, 10), subplot_kw={'polar': True})
    med_all = make_panel_c(ax, df)
    ax.text(-0.10, 1.10, 'C', transform=ax.transAxes, fontsize=40, fontweight='bold', va='top')
    from matplotlib.patches import Patch
    legend_elements = [Patch(facecolor=ECST_COLORS[e], edgecolor='none', label=e) for e in ECST_ORDER]
    ax.legend(handles=legend_elements, loc='center left', bbox_to_anchor=(1.15, 0.5), fontsize=20)
    save_fig(fig, outdir, 'Figure5C')
    plt.close()
    return med_all


def make_figure5D(df, outdir):
    fig, ax = plt.subplots(figsize=(9, 7))
    groups = bar_plot(ax, df, 'McMonnies_Questionnaire', 'McMonnies score', [(0, 2)])
    ax.text(-0.15, 1.05, 'D', transform=ax.transAxes, fontsize=40, fontweight='bold', va='top')
    save_fig(fig, outdir, 'Figure5D')
    plt.close()
    return groups


def make_figure5E(df, outdir):
    fig, ax = plt.subplots(figsize=(9, 7))
    groups = bar_plot(ax, df, 'MGD_grade_num', 'MGD grade', [(0, 2), (1, 2)])
    ax.text(-0.15, 1.05, 'E', transform=ax.transAxes, fontsize=40, fontweight='bold', va='top')
    save_fig(fig, outdir, 'Figure5E')
    plt.close()
    return groups


def make_figure5F(df, outdir):
    fig, ax = plt.subplots(figsize=(9, 7))
    groups = bar_plot(ax, df, 'MGL_total', 'Meibomian gland loss\n(total score)', [(0, 2), (1, 2)])
    ax.text(-0.15, 1.05, 'F', transform=ax.transAxes, fontsize=40, fontweight='bold', va='top')
    save_fig(fig, outdir, 'Figure5F')
    plt.close()
    return groups


def _draw_trajectory(ax, df, var, ylabel):
    traj1 = ['ECST_1', 'ECST_3', 'ECST_4']
    traj2 = ['ECST_1', 'ECST_3', 'ECST_2']
    for tj, lb, col, mk, ls, off in [
        (traj1, '1→3→4', TRAJ_COLORS['1→3→4'], 's', '-',  0.04),
        (traj2, '1→3→2', TRAJ_COLORS['1→3→2'], 'o', '--', -0.04),
    ]:
        ms, ss = [], []
        for ecst in tj:
            v = df[df['ECST']==ecst][var].dropna()
            ms.append(v.mean()); ss.append(sem(v))
        xs = np.array([0, 1, 2]) + off
        ax.errorbar(xs, ms, yerr=ss, fmt=mk+ls, color=col,
                    markersize=12, markeredgecolor='white', markeredgewidth=0.7,
                    linewidth=3.0, elinewidth=1.5, capsize=7, capthick=1.5,
                    label=f'ECST {lb}', zorder=3)
    ax.set_xticks([0, 1, 2])
    ax.set_xticklabels(['ECST_1', 'ECST_3', 'End'], fontsize=18)
    ax.set_ylabel(ylabel)

    sub1 = df[df['ECST'].isin(traj1)].copy()
    sub1['r'] = sub1['ECST'].map({e: i for i, e in enumerate(traj1)})
    r1, p1 = stats.spearmanr(sub1['r'], sub1[var])
    sub2 = df[df['ECST'].isin(traj2)].copy()
    sub2['r'] = sub2['ECST'].map({e: i for i, e in enumerate(traj2)})
    r2, p2 = stats.spearmanr(sub2['r'], sub2[var])
    s1 = ' ***' if p1 < 0.001 else ' **' if p1 < 0.01 else ' *' if p1 < 0.05 else ''
    s2 = ' ***' if p2 < 0.001 else ' **' if p2 < 0.01 else ' *' if p2 < 0.05 else ''
    ax.text(0.97, 0.05, f'1→3→4 ρ={r1:+.2f}{s1}\n1→3→2 ρ={r2:+.2f}{s2}',
            transform=ax.transAxes, fontsize=16, ha='right', va='bottom', color='#444',
            bbox=dict(facecolor='#fafafa', edgecolor='#ddd', boxstyle='round,pad=0.3', lw=0.5))
    return r1, p1, r2, p2


def _traj_legend():
    from matplotlib.lines import Line2D
    return [
        Line2D([0], [0], color=TRAJ_COLORS['1→3→4'], marker='s', ls='-',
               ms=12, mec='white', lw=3, label='ECST 1→3→4'),
        Line2D([0], [0], color=TRAJ_COLORS['1→3→2'], marker='o', ls='--',
               ms=12, mec='white', lw=3, label='ECST 1→3→2'),
    ]


def make_figure5G(df, outdir):
    fig, ax = plt.subplots(figsize=(8, 6.5))
    r1, p1, r2, p2 = _draw_trajectory(ax, df, 'MGD_grade_num', 'MGD grade')
    ax.text(-0.18, 1.10, 'G', transform=ax.transAxes, fontsize=40, fontweight='bold', va='top')
    ax.legend(handles=_traj_legend(), loc='upper left', fontsize=18)
    save_fig(fig, outdir, 'Figure5G')
    plt.close()
    return r1, p1, r2, p2


def make_figure5H(df, outdir):
    fig, ax = plt.subplots(figsize=(8, 6.5))
    r1, p1, r2, p2 = _draw_trajectory(ax, df, 'MGL_total', 'Meibomian gland loss')
    ax.text(-0.18, 1.10, 'H', transform=ax.transAxes, fontsize=40, fontweight='bold', va='top')
    ax.legend(handles=_traj_legend(), loc='upper left', fontsize=18)
    save_fig(fig, outdir, 'Figure5H')
    plt.close()
    return r1, p1, r2, p2


def make_figure5I(df, outdir):
    fig, ax = plt.subplots(figsize=(8, 6.5))
    r1, p1, r2, p2 = _draw_trajectory(ax, df, 'McMonnies_Questionnaire', 'McMonnies score')
    ax.text(-0.18, 1.10, 'I', transform=ax.transAxes, fontsize=40, fontweight='bold', va='top')
    ax.legend(handles=_traj_legend(), loc='upper left', fontsize=18)
    save_fig(fig, outdir, 'Figure5I')
    plt.close()
    return r1, p1, r2, p2


def make_figure5J(df, outdir):
    fig, ax = plt.subplots(figsize=(8, 6.5))
    r1, p1, r2, p2 = _draw_trajectory(ax, df, 'Age', 'Age (years)')
    ax.text(-0.18, 1.10, 'J', transform=ax.transAxes, fontsize=40, fontweight='bold', va='top')
    ax.legend(handles=_traj_legend(), loc='upper left', fontsize=18)
    save_fig(fig, outdir, 'Figure5J')
    plt.close()
    return r1, p1, r2, p2


def export_tables(df, outdir):
    traj1 = ['ECST_1', 'ECST_3', 'ECST_4']
    traj2 = ['ECST_1', 'ECST_3', 'ECST_2']

    radar_vars = [
        ('MGD_grade_num', 'MGD grade', False),
        ('MGL_total', 'MG loss', False),
        ('McMonnies_Questionnaire', 'McMonnies', False),
        ('TBUT_num', 'TBUT', True),
        ('Age', 'Age', False),
        ('OSDI', 'OSDI', False),
    ]
    rows_c = []
    for var, label, invert in radar_vars:
        vals = df[var].dropna()
        vmin, vmax = vals.min(), vals.max()
        for ecst in ECST_ORDER:
            m = df[df['ECST']==ecst][var].dropna().median()
            n = (m - vmin)/(vmax - vmin) if vmax > vmin else 0.5
            if invert: n = 1.0 - n
            rows_c.append({'Variable': label, 'ECST': ecst,
                           'Median_raw': round(m, 3), 'Normalized': round(n, 4),
                           'Inverted': invert})
    df_c = pd.DataFrame(rows_c)
    df_c.to_csv(f'{outdir}/STable_Figure5C.tsv', sep='\t', index=False)

    bar_panels = [
        ('Figure5D', 'McMonnies_Questionnaire', 'McMonnies score'),
        ('Figure5E', 'MGD_grade_num', 'MGD grade'),
        ('Figure5F', 'MGL_total', 'Meibomian gland loss (total score)'),
    ]
    bar_dfs = {}
    for panel, var, label in bar_panels:
        rows = []
        groups = [df[df['ECST']==e][var].dropna().values for e in ECST_ORDER]
        pkw = stats.kruskal(*[g for g in groups if len(g) >= 2]).pvalue
        for ecst, g in zip(ECST_ORDER, groups):
            rows.append({
                'ECST': ecst, 'n': len(g),
                'Mean': round(np.mean(g), 3), 'SEM': round(sem(g), 3),
                'Median': round(np.median(g), 3),
                'Kruskal_Wallis_P': round(pkw, 6),
            })
        df_bar = pd.DataFrame(rows)
        df_bar.to_csv(f'{outdir}/STable_{panel}.tsv', sep='\t', index=False)
        bar_dfs[panel] = df_bar

    traj_panels = [
        ('Figure5G', 'MGD_grade_num', 'MGD grade'),
        ('Figure5H', 'MGL_total', 'Meibomian gland loss'),
        ('Figure5I', 'McMonnies_Questionnaire', 'McMonnies score'),
        ('Figure5J', 'Age', 'Age (years)'),
    ]
    traj_dfs = {}
    for panel, var, label in traj_panels:
        rows = []
        for tj, tname in [(traj1, '1→3→4'), (traj2, '1→3→2')]:
            sub = df[df['ECST'].isin(tj)].copy()
            sub['rank'] = sub['ECST'].map({e: i for i, e in enumerate(tj)})
            vd = sub[['rank', var]].dropna()
            r, p = stats.spearmanr(vd['rank'], vd[var])
            for ecst in tj:
                g = df[df['ECST']==ecst][var].dropna()
                rows.append({
                    'Trajectory': tname, 'ECST': ecst,
                    'n': len(g), 'Mean': round(g.mean(), 3), 'SEM': round(sem(g), 3),
                    'Spearman_rho': round(r, 4), 'Spearman_P': round(p, 6),
                    'Sig': '***' if p < 0.001 else '**' if p < 0.01 else '*' if p < 0.05 else 'ns',
                })
        df_traj = pd.DataFrame(rows)
        df_traj.to_csv(f'{outdir}/STable_{panel}.tsv', sep='\t', index=False)
        traj_dfs[panel] = df_traj

    xlsx_path = f'{outdir}/STable_Figure5.xlsx'
    with pd.ExcelWriter(xlsx_path, engine='openpyxl') as writer:
        df_c.to_excel(writer, sheet_name='Figure5C', index=False)
        for panel, _, _ in bar_panels:
            bar_dfs[panel].to_excel(writer, sheet_name=panel, index=False)
        for panel, _, _ in traj_panels:
            traj_dfs[panel].to_excel(writer, sheet_name=panel, index=False)
    print(f"  TSV tables and Excel saved → {outdir}")


def main():
    parser = argparse.ArgumentParser(
        description='Generate Figure 5C–J for ECST clinical analysis.')
    parser.add_argument('--input', '-i', required=True,
                        help='Input TSV file (e.g. clinical.tsv)')
    parser.add_argument('--outdir', '-o', default='./output',
                        help='Output directory (default: ./output)')
    args = parser.parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    set_rcparams()
    print(f"Loading {args.input} ...")
    df = load_data(args.input)
    print(f"  {df.shape[0]} samples, {df['ECST'].nunique()} ECST subtypes")

    print("Generating Figure 5C–J ...")
    make_figure5C(df, args.outdir)
    make_figure5D(df, args.outdir)
    make_figure5E(df, args.outdir)
    make_figure5F(df, args.outdir)
    make_figure5G(df, args.outdir)
    make_figure5H(df, args.outdir)
    make_figure5I(df, args.outdir)
    make_figure5J(df, args.outdir)

    print("Exporting supplementary tables ...")
    export_tables(df, args.outdir)

    print(f"\nDone. All outputs saved to: {args.outdir}")


if __name__ == '__main__':
    main()
