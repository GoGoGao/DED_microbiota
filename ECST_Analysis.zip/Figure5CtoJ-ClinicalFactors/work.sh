python ecst_clinical_figure.py --input clinical.tsv --outdir ./output
