#Rscript ECST_pipeline.R --abundance ../input/species.relative.abundance.tsv --metadata ../input/group.tsv --outdir results
less results/M02_DMM/ecst_assignment.tsv |cut -f 1,2 > group.tsv
ln -s results/M01_MMUPHin/abundance_corrected.tsv
Rscript ECST_network_compare.R 
