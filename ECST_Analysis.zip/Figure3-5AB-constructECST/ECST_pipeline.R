#!/usr/bin/env Rscript
# ECST_pipeline.R — Ocular Surface Microbiome ECST Typing Pipeline (v6)
#
# 分型构建流程 (M01 + M02) 与 kraken2 版本完全一致:
#   1. 支持 kraken2 输出的物种名格式 (k__XXX|s__Species_name)，自动解析清理
#   2. 重复物种名自动合并 (group_by → sum)
#   3. 跨队列一致性预过滤 (队列内均值 ≥ 阈值，需达标队列数 ≥ min_cohorts)
#   4. MMUPHin 批次校正 (自动检测 Cohort-Group 共线性)
#   5. DMM 分型 + Silhouette violin 图 (最优 k 的分布)
#   6. k 值选择: 手动指定 或 Sil top3 候选 → 取 Laplace 最小
#
# 输出 figure 编号和展示内容与原始版保持一致
#
# Usage:
#   Rscript ECST_pipeline.R \
#     --abundance /path/to/total_relative.xls \
#     --metadata  /path/to/group.tsv \
#     --outdir    /path/to/output
#
# Optional arguments:
#   --mean_abd_thr   Per-cohort mean abundance threshold (default: 0.0054)
#   --min_cohorts    Minimum cohorts a species must pass threshold in (default: 2)
#   --manual_k       Number of ECSTs; set 0 for auto-selection (default: 4)
#   --kmax           Maximum k for DMM (default: 8)
#   --exclude        Comma-separated cohorts to exclude (default: none)
#   --seed           Random seed (default: 2025)
#
# Dependencies: MMUPHin, DirichletMultinomial, vegan, cluster, tidyverse,
#   ComplexHeatmap, circlize, ggpubr, ggrepel, patchwork, gridExtra,
#   slingshot, SingleCellExperiment (optional, for trajectory analysis)

suppressPackageStartupMessages(library(optparse))

option_list <- list(
  make_option("--abundance", type = "character", help = "Species abundance table (TSV/XLS, supports kraken2 k__|s__ format)"),
  make_option("--metadata",  type = "character", help = "Metadata (TSV)"),
  make_option("--outdir",    type = "character", default = "output", help = "Output directory"),
  make_option("--exclude",   type = "character", default = "", help = "Cohorts to exclude, comma-separated"),
  make_option("--mean_abd_thr", type = "double", default = 0.0054,
              help = "Per-cohort mean abundance threshold (default: 0.0054)"),
  make_option("--min_cohorts",  type = "integer", default = 2L,
              help = "Minimum cohorts for species retention (default: 2)"),
  make_option("--prev",      type = "double",    default = 0,
              help = "Prevalence filter threshold, fallback when species < 3 (default: 0)"),
  make_option("--manual_k", type = "integer", default = 4L,
              help = "Manual k; 0 = auto-selection (default: 4)"),
  make_option("--kmax",      type = "integer",   default = 8L, help = "Maximum k for DMM (default: 8)"),
  make_option("--seed",      type = "integer",   default = 2025L, help = "Random seed (default: 2025)")
)

opt <- parse_args(OptionParser(option_list = option_list))
if (is.null(opt$abundance) || is.null(opt$metadata))
  stop("--abundance and --metadata are required")

ABUNDANCE_FILE   <- opt$abundance
METADATA_FILE    <- opt$metadata
BASE_OUT         <- opt$outdir
EXCLUDED_COHORTS <- if (nchar(opt$exclude) > 0) strsplit(opt$exclude, ",")[[1]] else character(0)
MEAN_ABD_THR     <- opt$mean_abd_thr
MIN_COHORTS      <- opt$min_cohorts
PREV_THR         <- opt$prev
MANUAL_K         <- if (opt$manual_k == 0L) NULL else opt$manual_k
K_MAX            <- opt$kmax
SEED             <- opt$seed
ABD_THR          <- 1e-5
PSEUDO           <- 1e-5

if (!is.null(MANUAL_K)) {
  if (MANUAL_K < 2 || MANUAL_K > K_MAX)
    stop(sprintf("--K must be between 2 and %d, got: %d", K_MAX, MANUAL_K))
}

suppressPackageStartupMessages({
  library(MMUPHin); library(DirichletMultinomial)
  library(vegan); library(cluster); library(ape)
  library(tidyverse); library(patchwork); library(ggpubr); library(ggrepel)
  library(ComplexHeatmap); library(circlize); library(gridExtra)
})

# 解决 plyr/dplyr 命名空间冲突 (MMUPHin 依赖 plyr)
if ("package:plyr" %in% search()) {
  detach("package:plyr", unload = FALSE, force = TRUE)
}
library(dplyr, warn.conflicts = FALSE)

make_outdir <- function(m) { d <- file.path(BASE_OUT, m); dir.create(d, recursive = TRUE, showWarnings = FALSE); d }

CNS_THEME <- theme_classic(base_size = 7) +
  theme(axis.line = element_line(linewidth = 0.3, color = "black"),
        axis.ticks = element_line(linewidth = 0.2, color = "black"),
        axis.text = element_text(size = 6, color = "black"),
        axis.title = element_text(size = 7, color = "black"),
        legend.text = element_text(size = 5.5),
        legend.title = element_text(size = 6.5, face = "bold"),
        legend.key.size = unit(2.5, "mm"),
        legend.background = element_rect(fill = "white", color = NA),
        strip.text = element_text(size = 6.5, face = "bold"),
        strip.background = element_blank(),
        panel.grid = element_blank(),
        plot.tag = element_text(size = 8, face = "bold"),
        plot.title = element_text(size = 8, face = "bold", hjust = 0),
        plot.subtitle = element_text(size = 6, face = "italic"),
        plot.margin = margin(3, 3, 3, 3, "pt"))

AXIS_ROTATE_45 <- theme(axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1, size = 5))

COHORT_COLORS <- c("PRJCA002217"="#3C5488","PRJCA016672"="#E64B35","PRJEB38989"="#4DBBD5",
                   "PRJEB55149"="#00A087","PRJNA1261000"="#F39B7F","PRJNA774492"="#8491B4",
                   "PRJNA886972"="#91D1C2")

SPECIES_PALETTE <- c(
  "#D94F4F", "#3674B5", "#1A7A5E", "#E08A28", "#8555B3",
  "#2BB57A", "#C74E8A", "#5DA4D9", "#A67B2E", "#6B8E23",
  "#E06060", "#4B7FA8", "#9C5E2E", "#7CB87C", "#B074C8",
  "#D48C6A", "#408080", "#C25D5D", "#6A6AAD", "#88B04B"
)

assign_sp_colors <- function(sp_ranked) {
  n <- length(sp_ranked)
  pal <- rep(SPECIES_PALETTE, length.out = n)
  cols <- setNames(pal[1:n], sp_ranked)
  cols["Others"] <- "#E5E5E5"
  cols["Unclassified"] <- "#CCCCCC"
  cols
}

ECST_PAL <- c("#E64B35","#4DBBD5","#00A087","#3C5488","#F39B7F","#8491B4","#91D1C2","#7E6148")

to_proportion <- function(mat) { mat[mat < 0] <- 0; cs <- colSums(mat); cs[cs == 0] <- 1; sweep(mat, 2, cs, "/") }
clr_transform <- function(mat) { mat[mat < 0] <- 0; m <- mat + PSEUDO; apply(m, 2, function(x) log(x) - mean(log(x))) }

save_fig <- function(p, path, w = 180, h = 120) {
  ggsave(paste0(path, ".pdf"), p, width = w, height = h, units = "mm", dpi = 300)
  ggsave(paste0(path, ".png"), p, width = w, height = h, units = "mm", dpi = 300)
  cat("  fig:", basename(path), "\n")
}
save_tsv <- function(df, path) {
  write.table(df, paste0(path, ".tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
}

# ====================================================================
# M01 — MMUPHin 批次校正
# 分型构建流程与 kraken2 版本完全一致
# ====================================================================
cat("\n== M01: MMUPHin Batch Correction ==\n")
OUT_M01 <- make_outdir("M01_MMUPHin")

species_raw <- read.table(ABUNDANCE_FILE, sep = "\t", header = TRUE, row.names = 1, check.names = FALSE)
meta_raw    <- read.table(METADATA_FILE, sep = "\t", header = TRUE, check.names = FALSE)
if (length(EXCLUDED_COHORTS) > 0) {
  meta_raw <- meta_raw[!meta_raw$Dataset %in% EXCLUDED_COHORTS, ]
}

# ── 物种名解析 (支持 kraken2 格式: k__XXX|p__...|s__Species_name) ──
# 自动提取 s__ 后面的物种名; 无 s__ 前缀则原样保留
original_names <- rownames(species_raw)
parsed_names <- sapply(original_names, function(nm) {
  m <- regmatches(nm, regexpr("s__[^|]+", nm))
  if (length(m) > 0) return(sub("^s__", "", m))
  return(nm)
})

# 解析后若有重复物种名 (kraken2 多行对应同一物种), 按行求和合并
if (any(duplicated(parsed_names))) {
  cat("  Duplicate parsed names detected:", sum(duplicated(parsed_names)),
      "- merging by sum\n")
  species_raw <- as.data.frame(species_raw)
  species_raw$sp_parsed <- parsed_names
  species_raw <- species_raw %>%
    group_by(sp_parsed) %>%
    summarise(across(everything(), sum)) %>%
    column_to_rownames("sp_parsed")
} else {
  rownames(species_raw) <- parsed_names
}
cat("  Species name parsing:", length(original_names), "->", nrow(species_raw), "(after dedup)\n")

common  <- intersect(colnames(species_raw), meta_raw$Sample)
species <- species_raw[, common]
meta    <- meta_raw[match(common, meta_raw$Sample), ]
rownames(meta) <- meta$Sample
meta$Cohort <- meta$Dataset
cat("  Samples:", length(common), "| Raw species:", nrow(species), "\n")

# ── 跨队列一致性预过滤 ──
# 对每个物种, 在每个队列内计算平均相对丰度
# 保留在 >= min_cohorts 个队列中均值 >= MEAN_ABD_THR 的物种
cat(sprintf("  Cross-cohort consistency filter: mean_abd >= %.4f in >= %d cohorts\n",
            MEAN_ABD_THR, MIN_COHORTS))
species_prop <- to_proportion(species)
cohort_list  <- unique(meta$Cohort)

cohort_mean_mat <- matrix(0, nrow = nrow(species_prop), ncol = length(cohort_list),
                          dimnames = list(rownames(species_prop), cohort_list))
for (coh in cohort_list) {
  coh_samples <- meta$Sample[meta$Cohort == coh]
  coh_samples <- intersect(coh_samples, colnames(species_prop))
  if (length(coh_samples) > 0)
    cohort_mean_mat[, coh] <- rowMeans(species_prop[, coh_samples, drop = FALSE])
}

cohort_pass  <- apply(cohort_mean_mat, 1, function(x) sum(x >= MEAN_ABD_THR))
species_keep <- names(cohort_pass[cohort_pass >= MIN_COHORTS])
cat("  Species passing filter:", length(species_keep), "/ total:", nrow(cohort_mean_mat), "\n")

# 保存过滤汇总
filter_summary <- data.frame(species = rownames(cohort_mean_mat),
                              n_cohorts_pass = cohort_pass,
                              stringsAsFactors = FALSE)
for (coh in cohort_list) filter_summary[[paste0("mean_", coh)]] <- cohort_mean_mat[, coh]
filter_summary <- filter_summary[order(-filter_summary$n_cohorts_pass), ]
save_tsv(filter_summary, file.path(OUT_M01, "species_cohort_filter_summary"))

# 回退策略: 若过滤后物种过少则用流行度过滤
if (length(species_keep) < 3) {
  cat("  Warning: too few species after filter (", length(species_keep),
      "), falling back to prevalence filter (>= ", PREV_THR * 100, "%)\n", sep = "")
  prev <- apply(species_prop, 1, function(x) mean(x > ABD_THR))
  species_filt <- to_proportion(species_prop[prev >= PREV_THR, , drop = FALSE])
  cat("  Fallback prevalence filter: ", nrow(species_filt), " species retained\n", sep = "")
} else {
  species_filt <- to_proportion(species_prop[species_keep, , drop = FALSE])
}

# ── 校正前 PCoA + PERMANOVA ──
clr_pre <- clr_transform(species_filt)
pcoa_from_clr <- function(clr_mat, meta_df) {
  d  <- dist(t(clr_mat), method = "euclidean")
  pc <- cmdscale(d, k = 2, eig = TRUE)
  ve <- round(pc$eig[1:2] / sum(abs(pc$eig)) * 100, 1)
  df <- data.frame(sample_id = colnames(clr_mat), PC1 = pc$points[,1], PC2 = pc$points[,2],
                   Cohort = meta_df[colnames(clr_mat), "Cohort"],
                   Group  = meta_df[colnames(clr_mat), "Group"])
  list(df = df, ve = ve, dist = d)
}
pre_res <- pcoa_from_clr(clr_pre, meta)
set.seed(SEED)
perm_pre <- adonis2(pre_res$dist ~ Cohort + Group, data = meta[colnames(clr_pre),],
                    permutations = 999, by = "margin")

# ── MMUPHin 批次校正 (自动检测 Cohort-Group 共线性) ──
gpc <- tapply(meta$Group, meta$Cohort, function(x) length(unique(x)))
if (any(gpc <= 1)) {
  cat("  Cohort-Group collinearity detected; running without covariates\n")
  fit <- adjust_batch(feature_abd = species_filt, batch = "Cohort",
                      data = meta[colnames(species_filt),], control = list(verbose = FALSE))
} else {
  fit <- adjust_batch(feature_abd = species_filt, batch = "Cohort", covariates = "Group",
                      data = meta[colnames(species_filt),], control = list(verbose = FALSE))
}
corrected <- fit$feature_abd_adj; corrected[corrected < 0] <- 0
corrected <- to_proportion(corrected)

# ── 校正后 PCoA + PERMANOVA ──
clr_post <- clr_transform(corrected)
post_res  <- pcoa_from_clr(clr_post, meta)
set.seed(SEED)
perm_post <- adonis2(post_res$dist ~ Cohort + Group, data = meta[colnames(clr_post),],
                     permutations = 999, by = "margin")

perm_comp <- data.frame(Stage = factor(c("Before","After"), levels = c("Before","After")),
                        R2 = c(perm_pre$R2[1], perm_post$R2[1]),
                        P  = c(perm_pre$`Pr(>F)`[1], perm_post$`Pr(>F)`[1]))

write.table(corrected, file.path(OUT_M01, "abundance_corrected.tsv"), sep="\t", quote=FALSE)
save_tsv(perm_comp, file.path(OUT_M01, "permanova_results"))
save_tsv(pre_res$df, file.path(OUT_M01, "pcoa_before"))
save_tsv(post_res$df, file.path(OUT_M01, "pcoa_after"))
cat(sprintf("  Batch R2: %.4f -> %.4f\n", perm_comp$R2[1], perm_comp$R2[2]))

# ====================================================================
# M02 — DMM 分型
# 分型构建流程与 kraken2 版本完全一致
# ====================================================================
cat("\n== M02: DMM Typing ==\n")
OUT_M02 <- make_outdir("M02_DMM")

abd  <- corrected
SCALE <- 10000
count_mat <- round(t(abd) * SCALE)
count_mat <- count_mat[, colSums(count_mat) > 0, drop = FALSE]
count_mat <- count_mat[rowSums(count_mat) > 0, , drop = FALSE]
cat("  Count matrix:", nrow(count_mat), "x", ncol(count_mat), "\n")

# ── DMM 拟合 (k = 1 到 K_MAX) ──
set.seed(SEED)
fit_list <- lapply(1:K_MAX, function(k) {
  cat("  k=", k, "..."); f <- dmn(count_mat, k=k, verbose=FALSE)
  cat(" Lap=", round(laplace(f)), "\n"); f
})

laps <- sapply(fit_list, laplace)
bics <- sapply(fit_list, BIC)

# ── Silhouette 扫描 ──
bc_dmm <- vegdist(count_mat, method = "bray")
bc_mat <- as.matrix(bc_dmm); bc_mat[is.nan(bc_mat)] <- 0; bc_dmm <- as.dist(bc_mat)

sil_scan <- sapply(2:K_MAX, function(k) {
  a <- apply(mixture(fit_list[[k]]), 1, which.max)
  mean(silhouette(a, dist = bc_dmm)[, "sil_width"])
})
names(sil_scan) <- 2:K_MAX
sil_scan_df <- data.frame(k = 2:K_MAX, avg_sil = sil_scan)

# ── k 值选择: Sil top3 候选 → 取 Laplace 最小 ──
sil_top3    <- sort(sil_scan, decreasing = TRUE)[1:min(3, length(sil_scan))]
candidates  <- as.integer(names(sil_top3))
auto_k      <- candidates[which.min(laps[candidates])]
cat(sprintf("  Laplace optimal: k=%d | BIC optimal: k=%d | Sil optimal: k=%s\n",
            which.min(laps), which.min(bics), names(which.max(sil_scan))))
cat(sprintf("  Auto selection: k=%d (Sil=%.3f)\n", auto_k, sil_scan[as.character(auto_k)]))

if (!is.null(MANUAL_K)) {
  optimal_k <- MANUAL_K
  cat(sprintf("  Manual override: using k=%d (Laplace=%.0f, Sil=%.3f)\n",
              optimal_k, laps[optimal_k], sil_scan[as.character(optimal_k)]))
} else {
  optimal_k <- auto_k
}

model_sel <- data.frame(k = 1:K_MAX, Laplace = laps, BIC = bics,
                        Silhouette = c(NA, sil_scan))

# ── ECST 归属 ──
best_fit    <- fit_list[[optimal_k]]
post_probs  <- mixture(best_fit)
ecst_assign <- apply(post_probs, 1, which.max)
comp_means  <- fitted(best_fit)       # taxa × k
colnames(comp_means) <- paste0("ECST_", 1:optimal_k)

ecst_df <- data.frame(sample_id = rownames(count_mat),
                      ECST = paste0("ECST_", ecst_assign),
                      posterior_prob = round(apply(post_probs, 1, max), 4),
                      stringsAsFactors = FALSE) %>%
  left_join(meta, by = c("sample_id" = "Sample"))
cat("  ECST distribution:\n"); print(table(ecst_df$ECST))

# ── Silhouette (最优 k) ──
sil     <- silhouette(ecst_assign, dist = bc_dmm)
avg_sil <- mean(sil[, "sil_width"])
sil_df  <- data.frame(ECST = paste0("ECST_", sil[,"cluster"]), sil_width = sil[,"sil_width"])

ecst_colors <- setNames(ECST_PAL[1:optimal_k], paste0("ECST_", 1:optimal_k))
ecst_levels <- sort(unique(ecst_df$ECST))

# ── 输出 TSV ──
save_tsv(model_sel, file.path(OUT_M02, "dmm_model_selection"))
save_tsv(ecst_df,   file.path(OUT_M02, "ecst_assignment"))
write.table(as.data.frame(comp_means), file.path(OUT_M02, "dmm_component_means.tsv"),
            sep="\t", quote=FALSE)
save_tsv(sil_scan_df, file.path(OUT_M02, "silhouette_scan"))
save_tsv(sil_df, file.path(OUT_M02, "silhouette_values"))
saveRDS(best_fit, file.path(OUT_M02, "dmm_best_fit.rds"))
saveRDS(fit_list, file.path(OUT_M02, "dmm_fit_list.rds"))

# 同步 abd: 只保留有 ECST 归属的样本
abd  <- abd[, colnames(abd) %in% ecst_df$sample_id, drop=FALSE]
meta <- meta[rownames(meta) %in% ecst_df$sample_id, ]

# ====================================================================
# M03: Composition
# ====================================================================
cat("\n== M03: Composition ==\n")
OUT_M03 <- make_outdir("M03_Composition")

ecst_naming <- data.frame(
  ECST_id = colnames(comp_means),
  dominant = apply(comp_means, 2, function(x) rownames(comp_means)[which.max(x)]),
  dom_prop = apply(comp_means, 2, function(x) max(x)/sum(x)),
  stringsAsFactors = FALSE
) %>% mutate(ECST_name = ifelse(dom_prop > 0.3,
  paste0("ECST-", substr(gsub("_.*","",dominant),1,1), gsub(".*_","",dominant)), "ECST-Diverse"))
save_tsv(ecst_naming, file.path(OUT_M03, "ecst_naming"))

top10    <- names(sort(rowMeans(abd), decreasing=TRUE))[1:10]
sp_order <- c(top10, "Others")
sp_colors <- assign_sp_colors(top10)
sp_labels <- setNames(gsub("_"," ", sp_order), sp_order)

div_df <- data.frame(sample_id=colnames(abd), Shannon=diversity(t(abd),"shannon"),
                     Richness=specnumber(t(abd)), Dominance=apply(abd,2,max)*100,
                     stringsAsFactors=FALSE) %>%
  left_join(ecst_df[,c("sample_id","ECST","Dataset","Group")], by="sample_id") %>%
  filter(!is.na(ECST))
save_tsv(div_df, file.path(OUT_M03, "diversity_by_ecst"))

abd_long <- as.data.frame(abd) %>% rownames_to_column("species") %>%
  pivot_longer(-species, names_to="sample_id", values_to="abundance") %>%
  left_join(ecst_df[,c("sample_id","ECST","Dataset")], by="sample_id") %>%
  filter(!is.na(ECST)) %>%
  mutate(sp_grp = ifelse(species %in% top10, species, "Others")) %>%
  group_by(sample_id, sp_grp, ECST, Dataset) %>%
  summarise(abundance=sum(abundance), .groups="drop")

s_order <- abd_long %>% group_by(sample_id, ECST) %>%
  summarise(dom=max(abundance), .groups="drop") %>% arrange(ECST, desc(dom)) %>% pull(sample_id)
abd_long$sample_id <- factor(abd_long$sample_id, levels=s_order)
abd_long$sp_grp    <- factor(abd_long$sp_grp, levels=rev(sp_order))
abd_long$ECST      <- factor(abd_long$ECST, levels=ecst_levels)

actual_cohorts       <- sort(unique(ecst_df$Dataset))
actual_cohort_colors <- COHORT_COLORS[names(COHORT_COLORS) %in% actual_cohorts]

p3c <- ggplot(abd_long, aes(sample_id, abundance*100, fill=sp_grp)) +
  geom_bar(stat="identity", width=1, linewidth=0) +
  facet_grid(~ ECST, scales="free_x", space="free_x", switch="x") +
  scale_fill_manual(values=sp_colors, labels=sp_labels, name="Species",
                    guide=guide_legend(ncol=1)) +
  scale_y_continuous(expand=c(0,0), labels=function(x) paste0(x,"%")) +
  labs(x=NULL, y="Relative abundance") +
  CNS_THEME + theme(axis.text.x=element_blank(), axis.ticks.x=element_blank(),
                    strip.placement="outside", strip.text.x=element_text(size=5.5),
                    panel.spacing.x=unit(1,"mm"),
                    legend.text=element_text(size=5, face="italic", family="sans"))

strip_df <- ecst_df[match(s_order, ecst_df$sample_id),]
strip_df <- strip_df[!is.na(strip_df$sample_id), ]
strip_df$sample_id <- factor(strip_df$sample_id, levels=s_order)
strip_df$Dataset <- factor(strip_df$Dataset, levels=names(actual_cohort_colors))
strip_df$ECST    <- factor(strip_df$ECST, levels=ecst_levels)

p3s <- ggplot(strip_df, aes(sample_id, 1, fill=Dataset)) +
  geom_tile(width=1) +
  facet_grid(~ ECST, scales="free_x", space="free_x") +
  scale_fill_manual(values=actual_cohort_colors, name="Cohort", drop=TRUE) +
  scale_x_discrete(drop=FALSE) +
  theme_void() + theme(strip.text=element_blank(), legend.key.size=unit(2,"mm"),
                       legend.text=element_text(size=4.5),
                       legend.position="bottom", legend.box="horizontal",
                       panel.spacing.x=unit(1,"mm"))

suppressPackageStartupMessages(library(ggdendro))

tree_samples    <- ecst_df$sample_id[ecst_df$sample_id %in% colnames(abd) & !is.na(ecst_df$ECST)]
sample_ecst_map <- setNames(ecst_df$ECST[match(tree_samples, ecst_df$sample_id)], tree_samples)

dend_order        <- c()
dend_segments_all <- list()
dend_leaves_all   <- list()
x_offset          <- 0

for (ec in ecst_levels) {
  ec_samps <- names(sample_ecst_map[sample_ecst_map == ec])
  ec_samps <- ec_samps[ec_samps %in% tree_samples]
  if (length(ec_samps) < 2) {
    dend_order <- c(dend_order, ec_samps)
    if (length(ec_samps) == 1) {
      dend_leaves_all[[ec]] <- data.frame(x=x_offset+1, y=0, label=ec_samps, ECST=ec)
      x_offset <- x_offset + 1
    }
    next
  }
  bc_ec <- vegdist(t(abd[, ec_samps, drop=FALSE]), method="bray")
  bc_ec_m <- as.matrix(bc_ec); bc_ec_m[is.nan(bc_ec_m)] <- 0
  hc_ec   <- hclust(as.dist(bc_ec_m), method="average")
  dend_ec <- as.dendrogram(hc_ec)
  ec_order <- hc_ec$labels[hc_ec$order]
  dd  <- dendro_data(dend_ec, type="rectangle")
  seg <- segment(dd)
  seg$x    <- seg$x + x_offset
  seg$xend <- seg$xend + x_offset
  dend_segments_all[[ec]] <- seg
  lf      <- dd$labels
  lf$x    <- lf$x + x_offset
  lf$ECST <- ec
  dend_leaves_all[[ec]] <- lf
  dend_order <- c(dend_order, ec_order)
  x_offset   <- x_offset + length(ec_samps)
}

seg_df  <- bind_rows(dend_segments_all)
leaf_df <- bind_rows(dend_leaves_all)

p_dend <- ggplot(seg_df) +
  geom_segment(aes(x=x, y=y, xend=xend, yend=yend), linewidth=0.15, color="grey40") +
  geom_point(data=leaf_df, aes(x=x, y=0, color=ECST), size=0.3, alpha=0.8) +
  scale_color_manual(values=ecst_colors, guide="none") +
  scale_y_continuous(expand=c(0,0)) +
  scale_x_continuous(expand=c(0.002,0.002)) +
  coord_cartesian(clip="off") +
  labs(y="BC distance") +
  theme_void() +
  theme(axis.text.y=element_text(size=4, color="grey50"),
        axis.title.y=element_text(size=5, angle=90, color="grey50"),
        plot.margin=margin(2,3,0,3,"pt"))

abd_long_tree <- as.data.frame(abd[, dend_order, drop=FALSE]) %>%
  rownames_to_column("species") %>%
  pivot_longer(-species, names_to="sample_id", values_to="abundance") %>%
  left_join(ecst_df[,c("sample_id","ECST","Dataset")], by="sample_id") %>%
  filter(!is.na(ECST)) %>%
  mutate(sp_grp = ifelse(species %in% top10, species, "Others")) %>%
  group_by(sample_id, sp_grp, ECST, Dataset) %>%
  summarise(abundance=sum(abundance), .groups="drop")
abd_long_tree$sample_id <- factor(abd_long_tree$sample_id, levels=dend_order)
abd_long_tree$sp_grp    <- factor(abd_long_tree$sp_grp, levels=rev(sp_order))

p3c_tree <- ggplot(abd_long_tree, aes(sample_id, abundance*100, fill=sp_grp)) +
  geom_bar(stat="identity", width=1, linewidth=0) +
  scale_fill_manual(values=sp_colors, labels=sp_labels, name="Species",
                    guide=guide_legend(ncol=2)) +
  scale_y_continuous(expand=c(0,0), labels=function(x) paste0(x,"%")) +
  scale_x_discrete(expand=c(0.002,0.002)) +
  labs(x=NULL, y="Relative abundance") +
  CNS_THEME + theme(axis.text.x=element_blank(), axis.ticks.x=element_blank(),
                    plot.margin=margin(0,3,0,3,"pt"),
                    legend.text=element_text(size=5, face="italic", family="sans"))

strip_theme_base <- theme_void() +
  theme(legend.key.size=unit(2,"mm"), legend.text=element_text(size=4),
        legend.position="right", plot.margin=margin(0,3,0,25,"pt"),
        plot.title=element_text(size=5, hjust=0, face="bold", color="grey40",
                                margin=margin(0,0,0,0)))

ecst_strip_df <- data.frame(
  sample_id=factor(dend_order, levels=dend_order),
  ECST=sample_ecst_map[dend_order], stringsAsFactors=FALSE)
p3_ecst_strip <- ggplot(ecst_strip_df, aes(sample_id, 1, fill=ECST)) +
  geom_tile(width=1) +
  scale_fill_manual(values=ecst_colors, name="ECST") +
  scale_x_discrete(expand=c(0.002,0.002)) +
  labs(y=NULL, title="ECST") +
  strip_theme_base

cohort_strip_df <- data.frame(
  sample_id=factor(dend_order, levels=dend_order),
  Dataset=ecst_df$Dataset[match(dend_order, ecst_df$sample_id)], stringsAsFactors=FALSE)
cohort_strip_df$Dataset <- factor(cohort_strip_df$Dataset, levels=names(actual_cohort_colors))
p3_cohort_strip <- ggplot(cohort_strip_df, aes(sample_id, 1, fill=Dataset)) +
  geom_tile(width=1) +
  scale_fill_manual(values=actual_cohort_colors, name="Cohort", drop=TRUE) +
  scale_x_discrete(expand=c(0.002,0.002)) +
  labs(y=NULL, title="Cohort") +
  strip_theme_base

site_strip_df <- data.frame(
  sample_id=factor(dend_order, levels=dend_order),
  SamplingSite=ecst_df$SamplingSite[match(dend_order, ecst_df$sample_id)], stringsAsFactors=FALSE)
site_strip_df$SamplingSite[is.na(site_strip_df$SamplingSite)] <- "Unknown"
actual_sites <- sort(unique(site_strip_df$SamplingSite))
site_pal     <- c("#F39B7F","#8491B4","#91D1C2","#7E6148","#B09C85","#FFD700","#DAA520","#76D7C4")
SITE_COLORS  <- setNames(site_pal[seq_along(actual_sites)], actual_sites)
site_strip_df$SamplingSite <- factor(site_strip_df$SamplingSite, levels=actual_sites)

p3_site_strip <- ggplot(site_strip_df, aes(sample_id, 1, fill=SamplingSite)) +
  geom_tile(width=1) +
  scale_fill_manual(values=SITE_COLORS, name="Sampling Site", drop=TRUE) +
  scale_x_discrete(expand=c(0.002,0.002)) +
  labs(y=NULL, title="Site") +
  strip_theme_base

group_strip_df <- data.frame(
  sample_id=factor(dend_order, levels=dend_order),
  Group=ecst_df$Group[match(dend_order, ecst_df$sample_id)], stringsAsFactors=FALSE)
group_strip_df$Group[is.na(group_strip_df$Group)] <- "Unknown"
actual_groups <- sort(unique(group_strip_df$Group))
GROUP_COLORS_STRIP <- c("Control"="#4DBBD5","MGD"="#E64B35","Pterygium"="#00A087",
                         "DED"="#F39B7F","Dry_Eye"="#F39B7F","Unknown"="#D9D9D9",
                         "Blepharitis"="#8491B4","Keratitis"="#91D1C2")
for (g in actual_groups) {
  if (!g %in% names(GROUP_COLORS_STRIP)) {
    extra <- setdiff(c("#7E6148","#B09C85","#D4AC0D","#943126","#6C3483"), GROUP_COLORS_STRIP)
    GROUP_COLORS_STRIP[g] <- extra[1]
  }
}
group_strip_df$Group <- factor(group_strip_df$Group, levels=actual_groups)

p3_group_strip <- ggplot(group_strip_df, aes(sample_id, 1, fill=Group)) +
  geom_tile(width=1) +
  scale_fill_manual(values=GROUP_COLORS_STRIP, name="Disease", drop=TRUE) +
  scale_x_discrete(expand=c(0.002,0.002)) +
  labs(y=NULL, title="Disease") +
  strip_theme_base

country_strip_df <- data.frame(
  sample_id=factor(dend_order, levels=dend_order),
  Country=ecst_df$Country[match(dend_order, ecst_df$sample_id)], stringsAsFactors=FALSE)
country_strip_df$Country[is.na(country_strip_df$Country)] <- "Unknown"
actual_countries <- sort(unique(country_strip_df$Country))
country_pal      <- c("#E64B35","#3C5488","#00A087","#F39B7F","#8491B4","#D9D9D9")
COUNTRY_COLORS   <- setNames(country_pal[seq_along(actual_countries)], actual_countries)
country_strip_df$Country <- factor(country_strip_df$Country, levels=actual_countries)

p3_country_strip <- ggplot(country_strip_df, aes(sample_id, 1, fill=Country)) +
  geom_tile(width=1) +
  scale_fill_manual(values=COUNTRY_COLORS, name="Country", drop=TRUE) +
  scale_x_discrete(expand=c(0.002,0.002)) +
  labs(y=NULL, title="Country") +
  strip_theme_base

fig_4C <- p_dend / p3c_tree / p3_ecst_strip / p3_cohort_strip /
  p3_site_strip / p3_group_strip / p3_country_strip +
  plot_layout(heights=c(3, 12, 0.5, 0.5, 0.5, 0.5, 0.5), guides="collect") &
  theme(legend.position="right")

save_fig(fig_4C, file.path(OUT_M03, "Figure3C"), w=220, h=120)
cat("  Figure 3C saved\n")

# ====================================================================
# M04: Ordination + Trajectory
# ====================================================================
cat("\n== M04: Ordination + Trajectory ==\n")
OUT_M04 <- make_outdir("M04_Ordination")

nonzero  <- colSums(abd) > 0
abd_nz   <- abd[, nonzero, drop=FALSE]
ecst_nz  <- ecst_df[ecst_df$sample_id %in% colnames(abd_nz), ]

bc_ord <- vegdist(t(abd_nz), method="bray")
bc_m   <- as.matrix(bc_ord); bc_m[is.nan(bc_m)] <- 0; bc_ord <- as.dist(bc_m)

pcoa_r <- cmdscale(bc_ord, k=2, eig=TRUE)
ve_ord <- round(pcoa_r$eig[1:2] / sum(abs(pcoa_r$eig)) * 100, 1)
pcoa_df <- data.frame(sample_id=colnames(abd_nz), PC1=pcoa_r$points[,1], PC2=pcoa_r$points[,2]) %>%
  left_join(ecst_nz[,c("sample_id","ECST","Dataset")], by="sample_id")

set.seed(SEED)
perm_meta <- ecst_nz[match(colnames(abd_nz), ecst_nz$sample_id), ]
perm_meta <- perm_meta[!is.na(perm_meta$ECST), ]
bc_perm   <- as.dist(as.matrix(bc_ord)[perm_meta$sample_id, perm_meta$sample_id])
perm_ecst <- adonis2(bc_perm ~ ECST + Dataset, data=perm_meta, permutations=999, by="margin")
r2_ecst   <- round(perm_ecst$R2[1], 3); pv_ecst   <- perm_ecst$`Pr(>F)`[1]
r2_cohort <- round(perm_ecst$R2[2], 3); pv_cohort <- perm_ecst$`Pr(>F)`[2]

hull_pcoa     <- pcoa_df %>% group_by(ECST) %>% slice(chull(PC1, PC2)) %>% ungroup()
centroids_pcoa <- pcoa_df %>% group_by(ECST) %>%
  summarise(x=mean(PC1), y=mean(PC2), n=n(), .groups="drop") %>%
  mutate(label=paste0(ECST, "\n(n=", n, ")"))

p4a <- ggplot(pcoa_df, aes(PC1, PC2)) +
  geom_polygon(data=hull_pcoa, aes(fill=ECST), alpha=0.08, color=NA, show.legend=FALSE) +
  geom_polygon(data=hull_pcoa, aes(color=ECST), fill=NA, linewidth=0.3, linetype="dashed", show.legend=FALSE) +
  geom_point(aes(color=ECST, shape=Dataset), size=1.5, alpha=0.6, stroke=0.15) +
  geom_label(data=centroids_pcoa, aes(x, y, label=label, fill=ECST),
             color="white", fontface="bold", size=1.8, alpha=0.85,
             label.padding=unit(1.2,"pt"), label.size=0, show.legend=FALSE) +
  scale_color_manual(values=ecst_colors) + scale_fill_manual(values=ecst_colors) +
  scale_shape_manual(values=c(16,17,15,3,7,8,4,0,1,2)[1:length(unique(pcoa_df$Dataset))]) +
  labs(x=paste0("PCoA1 (", ve_ord[1], "%)"), y=paste0("PCoA2 (", ve_ord[2], "%)"),
       subtitle=sprintf("PERMANOVA: ECST R\u00b2=%.3f (P=%.3f) \n Cohort R\u00b2=%.3f (P=%.3f)",
                        r2_ecst, pv_ecst, r2_cohort, pv_cohort)) +
  CNS_THEME + guides(color=guide_legend(override.aes=list(size=2.5, alpha=1)),
                     shape=guide_legend(override.aes=list(size=2)))

save_tsv(pcoa_df, file.path(OUT_M04, "pcoa_coords"))

tryCatch({
  suppressPackageStartupMessages({
    library(slingshot)
    library(SingleCellExperiment)
  })

  sling_samps  <- pcoa_df$sample_id[!is.na(pcoa_df$ECST)]
  sling_coords <- as.matrix(pcoa_df[pcoa_df$sample_id %in% sling_samps, c("PC1","PC2")])
  rownames(sling_coords) <- sling_samps
  sling_ecst   <- pcoa_df$ECST[pcoa_df$sample_id %in% sling_samps]

  abd_sling <- abd[, sling_samps, drop=FALSE]
  abd_sling <- abd_sling[rowSums(abd_sling) > 0, , drop=FALSE]

  sce <- SingleCellExperiment(
    assays = list(counts = as.matrix(round(abd_sling * SCALE))),
    reducedDims = list(PCoA = sling_coords)
  )
  colData(sce)$ECST <- factor(sling_ecst)

  ecst_sizes    <- table(sling_ecst)
  start_cluster <- names(which.max(ecst_sizes))

  set.seed(SEED)
  sds <- slingshot(sce, clusterLabels = "ECST", reducedDim = "PCoA",
                   start.clus = start_cluster, stretch = 0, approx_points = 150)

  lineages       <- slingLineages(sds)
  n_lineages     <- length(lineages)
  pseudotime_mat <- slingPseudotime(sds)
  curves         <- slingCurves(sds)

  pt_df <- data.frame(sample_id = sling_samps, ECST = sling_ecst)
  for (i in seq_len(ncol(pseudotime_mat))) {
    pt_df[[paste0("pseudotime_L", i)]] <- pseudotime_mat[, i]
  }
  pt_df <- pt_df %>% left_join(ecst_df[,c("sample_id","Dataset")], by="sample_id")
  save_tsv(pt_df, file.path(OUT_M04, "slingshot_pseudotime"))

  traj_plots <- list()
  for (lin_idx in seq_len(n_lineages)) {
    curve_coords <- curves[[lin_idx]]$s[curves[[lin_idx]]$ord, ]
    curve_df     <- data.frame(PCoA1 = curve_coords[,1], PCoA2 = curve_coords[,2])

    pdata <- data.frame(
      PC1 = sling_coords[,1], PC2 = sling_coords[,2],
      ECST = sling_ecst,
      pseudotime = pseudotime_mat[, lin_idx]
    )

    p_traj <- ggplot(pdata, aes(PC1, PC2)) +
      geom_point(data = pdata[is.na(pdata$pseudotime),],
                 color="grey80", alpha=0.3, size=1) +
      geom_point(data = pdata[!is.na(pdata$pseudotime),],
                 aes(color=pseudotime), alpha=0.7, size=1.5) +
      scale_color_viridis_c(name="Pseudotime", option="C", na.value="grey80") +
      geom_path(data=curve_df, aes(x=PCoA1, y=PCoA2),
                linewidth=1.2, color="#E64B35", linetype="dashed") +
      geom_label(data=centroids_pcoa, aes(x, y, label=label),
                 fill="white", alpha=0.8, size=1.8, fontface="bold",
                 label.padding=unit(1.2,"pt"), label.size=0.2) +
      labs(x=paste0("PCoA1 (", ve_ord[1], "%)"),
           y=paste0("PCoA2 (", ve_ord[2], "%)"),
           title=paste0("Trajectory L", lin_idx, ": ",
                        paste(lineages[[lin_idx]], collapse=" ... "))) +
      CNS_THEME
    traj_plots[[lin_idx]] <- p_traj
  }

  fig_3B <- wrap_plots(c(list(p4a), traj_plots), nrow=1) +
    plot_annotation(tag_levels="A")
  save_fig(fig_3B, file.path(OUT_M04, "Figure4B"), w=300, h=85)
  cat("  Figure 4B saved\n")

  lineage_info <- data.frame(lineage=seq_along(lineages),
                              path=sapply(lineages, paste, collapse=" \u2192 "),
                              start=start_cluster, stringsAsFactors=FALSE)
  save_tsv(lineage_info, file.path(OUT_M04, "slingshot_lineages"))

}, error=function(e) {
  cat("  Slingshot skipped (requires slingshot + SingleCellExperiment):\n")
  cat("   ", conditionMessage(e), "\n")
  save_fig(p4a, file.path(OUT_M04, "Figure4B_PCoA_only"), w=110, h=85)
})

# ====================================================================
# M05: Diversity + Distribution
# ====================================================================
cat("\n== M05: Diversity + Distribution ==\n")
OUT_M05 <- make_outdir("M05_Diversity_ECST")

ecst_valid <- ecst_df %>% filter(!is.na(ECST))

kw_shannon  <- kruskal.test(Shannon ~ ECST, data=div_df)
kw_richness <- kruskal.test(Richness ~ ECST, data=div_df)

lm_div <- tryCatch({
  fit_s   <- lm(Shannon ~ ECST + Dataset, data=div_df)
  anova_s <- anova(fit_s)
  fit_r   <- lm(Richness ~ ECST + Dataset, data=div_df)
  anova_r <- anova(fit_r)
  data.frame(metric=c("Shannon","Richness"),
             ECST_P=c(anova_s["ECST","Pr(>F)"], anova_r["ECST","Pr(>F)"]),
             stringsAsFactors=FALSE)
}, error=function(e) data.frame(metric="Shannon", ECST_P=NA))
save_tsv(lm_div, file.path(OUT_M05, "ecst_diversity_cohort_adjusted"))

ecst_pairs <- combn(sort(unique(div_df$ECST)), 2, simplify=FALSE)
pw_results <- list()
for (pair in ecst_pairs) {
  d1 <- div_df$Shannon[div_df$ECST == pair[1]]
  d2 <- div_df$Shannon[div_df$ECST == pair[2]]
  wt <- wilcox.test(d1, d2, exact=FALSE)
  r1 <- div_df$Richness[div_df$ECST == pair[1]]
  r2 <- div_df$Richness[div_df$ECST == pair[2]]
  wt_r <- wilcox.test(r1, r2, exact=FALSE)
  pw_results[[paste(pair, collapse=" vs ")]] <- data.frame(
    group1=pair[1], group2=pair[2], Shannon_P=wt$p.value, Richness_P=wt_r$p.value,
    stringsAsFactors=FALSE)
}
pw_df <- bind_rows(pw_results)
pw_df$Shannon_Padj  <- p.adjust(pw_df$Shannon_P, method="BH")
pw_df$Richness_Padj <- p.adjust(pw_df$Richness_P, method="BH")
save_tsv(pw_df, file.path(OUT_M05, "ecst_pairwise_diversity"))

sig_pairs_shannon  <- pw_df %>% filter(Shannon_Padj < 0.1) %>%
  mutate(pair = purrr::map2(group1, group2, ~c(.x, .y))) %>% pull(pair)
sig_pairs_richness <- pw_df %>% filter(Richness_Padj < 0.1) %>%
  mutate(pair = purrr::map2(group1, group2, ~c(.x, .y))) %>% pull(pair)

cohort_subtitle <- if (!is.na(lm_div$ECST_P[1])) {
  sprintf("Cohort-adjusted ANOVA: Shannon P=%.2e, Richness P=%.2e",
          lm_div$ECST_P[1], lm_div$ECST_P[2])
} else { "" }

p_shannon <- ggplot(div_df, aes(ECST, Shannon, fill=ECST)) +
  geom_violin(alpha=0.5, width=0.8, linewidth=0.2, trim=FALSE, scale="width") +
  geom_boxplot(width=0.12, outlier.shape=NA, linewidth=0.2, fill="white", alpha=0.8) +
  geom_jitter(width=0.08, size=0.2, alpha=0.3, color="black") +
  scale_fill_manual(values=ecst_colors) +
  labs(x=NULL, y="Shannon diversity",
       subtitle=sprintf("Kruskal-Wallis P = %.2e", kw_shannon$p.value)) +
  CNS_THEME + theme(legend.position="none")
if (length(sig_pairs_shannon) > 0) {
  p_shannon <- p_shannon +
    stat_compare_means(comparisons=sig_pairs_shannon, method="wilcox.test",
                       label="p.signif", size=2.5, step.increase=0.08,
                       tip.length=0.01, bracket.size=0.3)
}

p_richness <- ggplot(div_df, aes(ECST, Richness, fill=ECST)) +
  geom_violin(alpha=0.5, width=0.8, linewidth=0.2, trim=FALSE, scale="width") +
  geom_boxplot(width=0.12, outlier.shape=NA, linewidth=0.2, fill="white", alpha=0.8) +
  geom_jitter(width=0.08, size=0.2, alpha=0.3, color="black") +
  scale_fill_manual(values=ecst_colors) +
  labs(x=NULL, y="Observed species",
       subtitle=sprintf("Kruskal-Wallis P = %.2e", kw_richness$p.value)) +
  CNS_THEME + theme(legend.position="none")
if (length(sig_pairs_richness) > 0) {
  p_richness <- p_richness +
    stat_compare_means(comparisons=sig_pairs_richness, method="wilcox.test",
                       label="p.signif", size=2.5, step.increase=0.08,
                       tip.length=0.01, bracket.size=0.3)
}

fig_3A <- (p_shannon | p_richness) +
  plot_annotation(title=cohort_subtitle,
                  theme=theme(plot.title=element_text(size=6, face="italic", hjust=0.5)))
save_fig(fig_3A, file.path(OUT_M05, "Figure4A"), w=130, h=75)
cat("  Figure 4A saved\n")

save_tsv(div_df, file.path(OUT_M05, "diversity_by_ecst"))

p_fig4A <- ggplot(model_sel, aes(k, Laplace)) +
  geom_line(color="#3C5488", linewidth=0.5) + geom_point(color="#3C5488", size=1.5) +
  geom_point(data=model_sel[optimal_k,], color="#E64B35", size=2.5, shape=18) +
  scale_x_continuous(breaks=1:K_MAX) +
  labs(x="Number of ECSTs (k)", y="Laplace") + CNS_THEME

p_fig4B <- ggplot(sil_scan_df, aes(k, avg_sil)) +
  geom_line(color="#00A087", linewidth=0.5) + geom_point(color="#00A087", size=1.5) +
  geom_point(data=sil_scan_df[sil_scan_df$k==optimal_k,], color="#E64B35", size=2.5, shape=18) +
  geom_hline(yintercept=0.5, linetype="dashed", linewidth=0.2) +
  scale_x_continuous(breaks=2:K_MAX) +
  labs(x="Number of ECSTs (k)", y="Avg Silhouette") + CNS_THEME

save_fig(p_fig4A, file.path(OUT_M05, "Figure3A"), w=70, h=65)
save_fig(p_fig4B, file.path(OUT_M05, "Figure3B"), w=70, h=65)
fig_4AB <- (p_fig4A | p_fig4B) + plot_annotation(tag_levels="A")
save_fig(fig_4AB, file.path(OUT_M05, "Figure3AB"), w=140, h=65)
cat("  Figure 3A, 3B saved\n")

prop_df <- ecst_valid %>% dplyr::count(Dataset, ECST) %>%
  group_by(Dataset) %>% mutate(prop=n/sum(n)) %>% ungroup()
co <- ecst_valid %>% dplyr::count(Dataset) %>% arrange(desc(n)) %>% pull(Dataset)
prop_df$Dataset <- factor(prop_df$Dataset, levels=co)

lbl_full <- ecst_valid %>% dplyr::count(Dataset) %>%
  mutate(l = paste0(Dataset, "\n(n=", n, ")")) %>%
  { setNames(.$l, .$Dataset) }

ft <- fisher.test(table(ecst_valid$Dataset, ecst_valid$ECST), simulate.p.value=TRUE, B=10000)

fig_4D <- ggplot(prop_df, aes(Dataset, prop, fill=ECST)) +
  geom_bar(stat="identity", width=0.7, color="white", linewidth=0.15) +
  scale_fill_manual(values=ecst_colors) +
  scale_y_continuous(expand=c(0,0), labels=scales::percent) +
  scale_x_discrete(labels=lbl_full) +
  annotate("text", x=0.5, y=0.98,
           label=sprintf("\u03c7\u00b2 test: P = %.1e", ft$p.value),
           hjust=0, vjust=1, size=2, fontface="italic") +
  labs(x=NULL, y="Proportion", title="ECST distribution per cohort") +
  CNS_THEME + AXIS_ROTATE_45

save_fig(fig_4D, file.path(OUT_M05, "Figure3D"), w=110, h=75)
cat("  Figure 3D saved\n")
save_tsv(prop_df, file.path(OUT_M05, "ecst_cohort_distribution"))

# ====================================================================
# M08: ECST Validation
# ====================================================================
cat("\n== M08: ECST Validation ==\n")
OUT_M08 <- make_outdir("M08_Validation")

core_list <- list()
for (ec in names(ecst_colors)) {
  s <- ecst_df$sample_id[ecst_df$ECST == ec]
  s <- s[s %in% colnames(abd)]
  if (length(s) < 2) next
  sub <- abd[, s, drop=FALSE]
  ma  <- rowMeans(sub)*100; pv <- rowSums(sub>0)/ncol(sub)*100
  core <- data.frame(species=names(ma), mean_abd=ma, prevalence=pv, ECST=ec, stringsAsFactors=FALSE) %>%
    filter(mean_abd > 1 & prevalence > 50) %>% arrange(desc(mean_abd))
  core_list[[ec]] <- core
}
core_all <- bind_rows(core_list)
save_tsv(core_all, file.path(OUT_M08, "core_species_by_ecst"))

ecst_naming_dom <- data.frame(ECST_id=colnames(comp_means),
                               dominant=apply(comp_means,2,function(x) rownames(comp_means)[which.max(x)]),
                               stringsAsFactors=FALSE)
top_def <- ecst_naming_dom

cohorts <- unique(ecst_df$Dataset)
core_consistency <- list()
for (ec in names(ecst_colors)) {
  dom_sp <- top_def$dominant[top_def$ECST_id == ec]
  if (length(dom_sp)==0 || is.na(dom_sp)) next
  if (!dom_sp %in% rownames(abd)) next
  for (coh in cohorts) {
    s <- ecst_df$sample_id[ecst_df$ECST == ec & ecst_df$Dataset == coh]
    s <- s[s %in% colnames(abd)]
    if (length(s) < 1) next
    core_consistency[[paste(ec, coh, dom_sp)]] <- data.frame(
      ECST=ec, cohort=coh, species=dom_sp,
      mean_abd=mean(abd[dom_sp, s])*100,
      prevalence=sum(abd[dom_sp, s]>0)/length(s)*100,
      n=length(s), stringsAsFactors=FALSE)
  }
}
core_con_df <- bind_rows(core_consistency)
save_tsv(core_con_df, file.path(OUT_M08, "core_species_consistency"))

fig_4E <- ggplot(core_con_df, aes(x=cohort, y=ECST, size=mean_abd, color=prevalence)) +
  geom_point() +
  scale_size_continuous(range=c(1,6), name="Mean abd. (%)") +
  scale_color_gradient(low="#FDDBC7", high="#B2182B", name="Prevalence (%)") +
  labs(x=NULL, y=NULL, title="Dominant species consistency") +
  CNS_THEME + AXIS_ROTATE_45
save_fig(fig_4E, file.path(OUT_M08, "Figure3E"), w=110, h=75)
cat("  Figure 3E saved\n")

ref_labels <- setNames(ecst_df$ECST, ecst_df$sample_id)

ari <- function(a, b) {
  tab <- table(a, b); n <- sum(tab)
  ai <- rowSums(tab); bj <- colSums(tab)
  sum_cij2 <- sum(choose(tab, 2))
  en <- sum(choose(ai, 2)) * sum(choose(bj, 2)) / choose(n, 2)
  num <- sum_cij2 - en
  den <- (sum(choose(ai, 2)) + sum(choose(bj, 2))) / 2 - en
  if (den == 0) return(1)
  num / den
}

nmi <- function(a, b) {
  tab <- table(a, b); n <- sum(tab)
  pi <- rowSums(tab)/n; pj <- colSums(tab)/n
  h_a <- -sum(pi[pi>0] * log(pi[pi>0]))
  h_b <- -sum(pj[pj>0] * log(pj[pj>0]))
  mi <- 0
  for (i in 1:nrow(tab)) for (j in 1:ncol(tab)) {
    if (tab[i,j] > 0) mi <- mi + tab[i,j]/n * log(tab[i,j]/n / (pi[i]*pj[j]))
  }
  if ((h_a + h_b) == 0) return(1)
  2 * mi / (h_a + h_b)
}

loco_results <- list()
for (leave_out in cohorts) {
  keep_samps <- ecst_df$sample_id[ecst_df$Dataset != leave_out]
  keep_samps <- keep_samps[keep_samps %in% colnames(abd)]
  if (length(keep_samps) < 20) next
  abd_loco <- abd[, keep_samps, drop=FALSE]
  abd_loco <- abd_loco[rowSums(abd_loco) > 0, , drop=FALSE]
  count_loco <- round(t(abd_loco) * SCALE)
  count_loco <- count_loco[rowSums(count_loco) > 0, colSums(count_loco) > 0, drop=FALSE]
  set.seed(SEED)
  fit_loco <- tryCatch(dmn(count_loco, k=optimal_k, verbose=FALSE), error=function(e) NULL)
  if (is.null(fit_loco)) next
  loco_assign <- paste0("ECST_", apply(mixture(fit_loco), 1, which.max))
  names(loco_assign) <- rownames(count_loco)
  common_samps <- intersect(names(loco_assign), names(ref_labels))
  ari_val <- ari(ref_labels[common_samps], loco_assign[common_samps])
  nmi_val <- nmi(ref_labels[common_samps], loco_assign[common_samps])
  loco_results[[leave_out]] <- data.frame(left_out=leave_out, n_remaining=length(keep_samps),
                                           ARI=ari_val, NMI=nmi_val, stringsAsFactors=FALSE)
}
loco_df <- bind_rows(loco_results)
save_tsv(loco_df, file.path(OUT_M08, "loco_results"))

leave_one_level_out <- function(ecst_df_in, abd_in, group_col, optimal_k_in, SEED_in, SCALE_in) {
  results <- list()
  levels_all <- unique(ecst_df_in[[group_col]])
  levels_all <- levels_all[!is.na(levels_all) & levels_all != ""]
  if (length(levels_all) < 2) return(NULL)
  for (lv in levels_all) {
    keep_samps <- ecst_df_in$sample_id[ecst_df_in[[group_col]] != lv | is.na(ecst_df_in[[group_col]])]
    keep_samps <- keep_samps[keep_samps %in% colnames(abd_in)]
    if (length(keep_samps) < 20) next
    abd_loo <- abd_in[, keep_samps, drop=FALSE]
    abd_loo <- abd_loo[rowSums(abd_loo) > 0, , drop=FALSE]
    count_loo <- round(t(abd_loo) * SCALE_in)
    count_loo <- count_loo[rowSums(count_loo) > 0, colSums(count_loo) > 0, drop=FALSE]
    set.seed(SEED_in)
    fit_loo <- tryCatch(dmn(count_loo, k=optimal_k_in, verbose=FALSE), error=function(e) NULL)
    if (is.null(fit_loo)) next
    loo_assign <- paste0("ECST_", apply(mixture(fit_loo), 1, which.max))
    names(loo_assign) <- rownames(count_loo)
    common_s <- intersect(names(loo_assign), names(ref_labels))
    if (length(common_s) < 10) next
    ari_val <- ari(ref_labels[common_s], loo_assign[common_s])
    nmi_val <- nmi(ref_labels[common_s], loo_assign[common_s])
    results[[lv]] <- data.frame(dimension=group_col, left_out=lv, n_remaining=length(keep_samps),
                                 ARI=ari_val, NMI=nmi_val, stringsAsFactors=FALSE)
  }
  bind_rows(results)
}

loo_dim_results <- list()
if ("SamplingSite" %in% colnames(ecst_df) && length(unique(ecst_df$SamplingSite)) >= 2)
  loo_dim_results[["SamplingSite"]] <- leave_one_level_out(ecst_df, abd, "SamplingSite", optimal_k, SEED, SCALE)
if ("Group" %in% colnames(ecst_df) && length(unique(ecst_df$Group[ecst_df$Group != "Unknown"])) >= 2)
  loo_dim_results[["Group"]] <- leave_one_level_out(ecst_df, abd, "Group", optimal_k, SEED, SCALE)
if ("Country" %in% colnames(ecst_df) && length(unique(ecst_df$Country)) >= 2)
  loo_dim_results[["Country"]] <- leave_one_level_out(ecst_df, abd, "Country", optimal_k, SEED, SCALE)

loo_all_dim <- bind_rows(loo_dim_results)

if (nrow(loo_all_dim) > 0) {
  save_tsv(loo_all_dim, file.path(OUT_M08, "loo_multidim_results"))
  loco_combined <- bind_rows(
    loco_df %>% mutate(dimension="Dataset") %>% select(dimension, left_out, n_remaining, ARI, NMI),
    loo_all_dim %>% select(dimension, left_out, n_remaining, ARI, NMI)
  )
  loco_combined$dimension <- factor(loco_combined$dimension,
    levels=c("Dataset","SamplingSite","Disease","Country"))

  fig_4F <- ggplot(loco_combined, aes(dimension, ARI, fill=dimension)) +
    geom_boxplot(alpha=0.6, width=0.5, linewidth=0.3, outlier.shape=NA) +
    geom_jitter(width=0.15, size=1.5, alpha=0.7) +
    geom_hline(yintercept=c(0.5, 0.8), linetype=c("dashed","dotted"),
               color="grey50", linewidth=0.2) +
    scale_fill_manual(values=c("Dataset"="#3C5488","SamplingSite"="#F39B7F",
                               "Disease"="#4DBBD5","Country"="#E64B35")) +
    scale_y_continuous(limits=c(0,1)) +
    annotate("text", x=Inf, y=0.82, label="Good (0.8)", hjust=1.1, size=2, color="grey50") +
    annotate("text", x=Inf, y=0.52, label="Moderate (0.5)", hjust=1.1, size=2, color="grey50") +
    labs(x=NULL, y="ARI", title="ECST robustness across grouping dimensions") +
    CNS_THEME + theme(legend.position="none")
  save_fig(fig_4F, file.path(OUT_M08, "Figure3F"), w=100, h=80)
  cat("  Figure 3F saved\n")
}

abd_nz2  <- abd[, colSums(abd) > 0, drop=FALSE]
ecst_nz2 <- ecst_df[ecst_df$sample_id %in% colnames(abd_nz2), ]
bc_vd    <- vegdist(t(abd_nz2), method="bray")
bc_vd_m  <- as.matrix(bc_vd); bc_vd_m[is.nan(bc_vd_m)] <- 0; bc_vd <- as.dist(bc_vd_m)

meta_vd <- ecst_nz2[ecst_nz2$sample_id %in% colnames(abd_nz2), ]
meta_vd <- meta_vd[!duplicated(meta_vd$sample_id), ]
rownames(meta_vd) <- meta_vd$sample_id

vd_terms <- c("Country","Dataset","ECST","SamplingSite")
vd_terms <- vd_terms[vd_terms %in% colnames(meta_vd)]
fml_str  <- paste("bc_vd ~", paste(vd_terms, collapse=" + "))
set.seed(SEED)
perm_vd <- adonis2(as.formula(fml_str), data=meta_vd, permutations=999, by="margin")

vd_df <- data.frame(term=rownames(perm_vd), R2=perm_vd$R2, P=perm_vd$`Pr(>F)`,
                    stringsAsFactors=FALSE) %>%
  filter(term != "Total" & term != "Residual")
vd_df$sig   <- ifelse(vd_df$P < 0.001, "***",
               ifelse(vd_df$P < 0.01, "**",
               ifelse(vd_df$P < 0.05, "*", "ns")))
vd_df$label <- sprintf("%.3f\n%s", vd_df$R2, vd_df$sig)

pre_samps  <- intersect(colnames(species_filt), meta_vd$sample_id)
vd_compare <- NULL
if (length(pre_samps) > 20) {
  tryCatch({
    bc_pre_vd <- vegdist(t(species_filt[, pre_samps, drop=FALSE]), method="bray")
    bc_pre_m  <- as.matrix(bc_pre_vd); bc_pre_m[is.nan(bc_pre_m)] <- 0; bc_pre_vd <- as.dist(bc_pre_m)
    meta_vd_pre   <- meta_vd[pre_samps, ]
    vd_terms_pre  <- vd_terms[vd_terms %in% colnames(meta_vd_pre)]
    fml_pre       <- paste("bc_pre_vd ~", paste(vd_terms_pre, collapse=" + "))
    set.seed(SEED)
    perm_vd_pre <- adonis2(as.formula(fml_pre), data=meta_vd_pre, permutations=999, by="margin")
    extract_r2 <- function(perm_res, stage) {
      df <- data.frame(term=rownames(perm_res), R2=perm_res$R2, P=perm_res$`Pr(>F)`,
                       stage=stage, stringsAsFactors=FALSE)
      df[!df$term %in% c("Total","Residual"), ]
    }
    vd_compare <- bind_rows(extract_r2(perm_vd_pre, "Before MMUPHin"),
                             extract_r2(perm_vd, "After MMUPHin"))
    vd_compare$stage <- factor(vd_compare$stage, levels=c("Before MMUPHin","After MMUPHin"))
    vd_compare$sig   <- ifelse(vd_compare$P < 0.001, "***",
                        ifelse(vd_compare$P < 0.01, "**",
                        ifelse(vd_compare$P < 0.05, "*", "ns")))
    vd_compare$label <- sprintf("%.3f\n%s", vd_compare$R2, vd_compare$sig)
    save_tsv(vd_compare, file.path(OUT_M08, "variance_decomposition_pre_vs_post"))
  }, error=function(e) cat("  Pre-correction variance decomposition failed:", conditionMessage(e), "\n"))
}

vd_colors <- c("ECST"="#E64B35","Dataset"="#3C5488","Country"="#00A087",
               "SamplingSite"="#F39B7F","Residual"="#D9D9D9")

if (!is.null(vd_compare)) {
  fig_4G <- ggplot(vd_compare, aes(term, R2, fill=term)) +
    geom_col(width=0.6, color="black", linewidth=0.3) +
    geom_text(aes(label=label), vjust=-0.2, size=2) +
    facet_wrap(~ stage) +
    scale_fill_manual(values=vd_colors, guide="none") +
    scale_y_continuous(expand=expansion(mult=c(0, 0.25))) +
    labs(x=NULL, y="PERMANOVA R\u00b2 (marginal)",
         title="Variance decomposition: before vs after batch correction") +
    CNS_THEME + AXIS_ROTATE_45
  save_fig(fig_4G, file.path(OUT_M08, "Figure3G"), w=160, h=85)
  cat("  Figure 3G saved\n")
}

# ====================================================================
# M07: Disease Association
# ====================================================================
cat("\n== M07: Disease Association ==\n")
OUT_M07 <- make_outdir("M07_Disease")

disease_cohorts <- ecst_df %>%
  filter(!is.na(ECST) & !is.na(Group) & Group != "Unknown") %>%
  group_by(Dataset) %>%
  summarise(has_ctrl = "Control" %in% Group,
            has_dis  = any(!Group %in% c("Control","Unknown")),
            n_ctrl   = sum(Group == "Control"),
            n_dis    = sum(!Group %in% c("Control","Unknown")),
            .groups  = "drop") %>%
  filter(has_ctrl & has_dis & n_ctrl >= 3 & n_dis >= 3) %>%
  pull(Dataset)

if (length(disease_cohorts) > 0) {
  ecst_dis        <- ecst_df %>% filter(Dataset %in% disease_cohorts & Group != "Unknown" & !is.na(ECST))
  ecst_dis_levels <- sort(unique(ecst_dis$ECST))
  ecst_dis_colors <- ecst_colors[ecst_dis_levels]

  fisher_per_cohort <- list()
  for (coh in disease_cohorts) {
    sub   <- ecst_dis %>% filter(Dataset==coh)
    cross <- table(sub$Group, sub$ECST); cross <- cross[,colSums(cross)>0, drop=FALSE]
    if (nrow(cross)<2) next
    ft <- fisher.test(cross, simulate.p.value=TRUE, B=10000)
    fisher_per_cohort[[coh]] <- data.frame(cohort=coh, fisher_p=ft$p.value)
  }

  fisher_labels <- bind_rows(fisher_per_cohort) %>%
    mutate(label = sprintf("Fisher P = %.2e", fisher_p))
  facet_labels  <- fisher_labels %>%
    mutate(facet_lab = paste0(cohort, "\n", label)) %>%
    { setNames(.$facet_lab, .$cohort) }

  prop_dis <- ecst_dis %>% dplyr::count(Dataset, Group, ECST) %>%
    group_by(Dataset, Group) %>% mutate(prop=n/sum(n)) %>% ungroup()

  fig_5A <- ggplot(prop_dis, aes(Group, prop, fill=ECST)) +
    geom_bar(stat="identity", width=0.6, color="white", linewidth=0.15) +
    facet_wrap(~ Dataset, scales="free_x",
               labeller=labeller(Dataset=facet_labels)) +
    scale_fill_manual(values=ecst_dis_colors) +
    scale_y_continuous(labels=scales::percent, expand=expansion(mult=c(0, 0.05))) +
    labs(x=NULL, y="Proportion") +
    CNS_THEME +
    theme(strip.text=element_text(size=6, face="bold", lineheight=1.2))
  save_fig(fig_5A, file.path(OUT_M07, "Figure5A"), w=130, h=75)
  cat("  Figure 5A saved\n")
  save_tsv(prop_dis, file.path(OUT_M07, "ecst_disease_proportion"))

  mgd_coh <- disease_cohorts[sapply(disease_cohorts, function(coh) {
    sub <- ecst_dis %>% filter(Dataset==coh)
    "MGD" %in% sub$Group && "Control" %in% sub$Group
  })]

  if (length(mgd_coh) > 0) {
    mgd_sub   <- ecst_dis %>% filter(Dataset %in% mgd_coh & Group %in% c("Control","MGD"))
    n_df      <- mgd_sub %>% dplyr::count(ECST, name="n_total")
    chisq_res <- tryCatch(
      chisq.test(table(mgd_sub$ECST, mgd_sub$Group), simulate.p.value=TRUE, B=10000),
      error=function(e) list(p.value=NA))

    mgd_prop <- mgd_sub %>%
      dplyr::count(ECST, Group) %>%
      group_by(ECST) %>% mutate(prop=n/sum(n)) %>% ungroup() %>%
      left_join(n_df, by="ECST") %>%
      mutate(ecst_label=paste0(ECST, "\n(n=", n_total, ")"))

    mgd_color    <- c("Control"="#4DBBD5","MGD"="#E64B35")
    mgd_label_df <- mgd_prop %>% filter(Group=="MGD") %>%
      mutate(label=paste0(round(prop*100), "%"))

    fig_5B <- ggplot(mgd_prop, aes(ecst_label, prop, fill=Group)) +
      geom_bar(stat="identity", width=0.6, color="white", linewidth=0.15) +
      geom_text(data=mgd_label_df, aes(ecst_label, 1-prop/2, label=label),
                size=2.5, fontface="bold", color="black") +
      geom_text(data=mgd_label_df %>% mutate(ctrl_prop=1-prop, label2=paste0(round(ctrl_prop*100),"%")),
                aes(ecst_label, ctrl_prop/2, label=label2),
                size=2.5, fontface="bold", color="black") +
      scale_fill_manual(values=mgd_color) +
      scale_y_continuous(expand=c(0,0), labels=scales::percent) +
      annotate("text", x=Inf, y=Inf,
               label=sprintf("\u03c7\u00b2 test\nP = %.2e", chisq_res$p.value),
               hjust=1.1, vjust=1.3, size=2.5, fontface="italic") +
      labs(x=NULL, y="Proportion (%)") +
      CNS_THEME
    save_fig(fig_5B, file.path(OUT_M07, "Figure5B"), w=90, h=75)
    cat("  Figure 5B saved\n")
    save_tsv(mgd_prop, file.path(OUT_M07, "mgd_proportion_by_ecst"))
  }
}

cat("\n== All figures generated ==\n")
cat("Output directory:", BASE_OUT, "\n")
cat("ECST k =", optimal_k, "| Avg Silhouette =", round(avg_sil, 3), "\n")
cat("Species:", nrow(abd), "| Samples:", ncol(abd), "\n")
