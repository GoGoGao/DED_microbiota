#!/usr/bin/env Rscript
# eye_network_ecst_comparison.R
# Co-occurrence network comparison across ECST types
#
# Usage:
#   Rscript eye_network.r
#   (Run in directory containing abundance_corrected.tsv and group.tsv)
#
# Input files (in working directory):
#   abundance_corrected.tsv  — MMUPHin-corrected relative abundance (species x samples)
#   group.tsv                — Sample grouping (columns: sample_id, ECST)
#
# Outputs (in result_network/):
#   plots/Figure4C_*.pdf/png  — Per-ECST network panels (Figure 4C)
#   plots/Figure4D_*.pdf/png  — Network topology bar charts (Figure 4D)
#   summary/*.tsv             — Network statistics tables

suppressPackageStartupMessages({
  library(tidyverse)
  library(WGCNA)
  library(igraph)
  library(ggraph)
  library(scales)
  library(ggpubr)
  library(patchwork)
  library(ggsci)
  library(ggrepel)
})

`%||%` <- function(a, b) if (!is.null(a) && length(a) > 0) a else b

WORK_DIR    <- "."
RESULT_ROOT <- file.path(WORK_DIR, "result_network")
PLOT_DIR    <- file.path(RESULT_ROOT, "plots")
SUMMARY_DIR <- file.path(RESULT_ROOT, "summary")

R_THR      <- 0.4
P_THR      <- 0.05
PREV_MIN   <- 0.10
LABEL_TOP  <- 18
MIN_MOD_SZ <- 3

for (d in c(RESULT_ROOT, PLOT_DIR, SUMMARY_DIR))
  if (!dir.exists(d)) dir.create(d, recursive = TRUE, showWarnings = FALSE)

ECST_PAL <- c(
  ECST_1 = "#C44E4B",
  ECST_2 = "#45B5C8",
  ECST_3 = "#259982",
  ECST_4 = "#375183"
)

EDGE_POS_COL <- "#2166AC"
EDGE_NEG_COL <- "#B2182B"

save_fig <- function(p, name, data = NULL, w = 8, h = 7, dpi = 300) {
  if (!is.null(p)) {
    ggsave(file.path(PLOT_DIR, paste0(name, ".pdf")), p,
           width = w, height = h, device = cairo_pdf)
    ggsave(file.path(PLOT_DIR, paste0(name, ".png")), p,
           width = w, height = h, dpi = dpi, bg = "white")
    message("  [fig] ", name)
  }
  if (!is.null(data))
    write_tsv(as_tibble(data), file.path(PLOT_DIR, paste0(name, ".tsv")))
}

theme_cns <- function(base = 10) {
  theme_classic(base_size = base, base_family = "sans") +
    theme(
      plot.title       = element_text(hjust = 0.5, face = "bold", size = base + 3,
                                       color = "black", margin = margin(b = 6)),
      plot.subtitle    = element_text(hjust = 0.5, color = "grey35", size = base,
                                       margin = margin(b = 8)),
      plot.tag          = element_text(face = "bold", size = base + 4),
      strip.background = element_blank(),
      strip.text       = element_text(face = "bold", size = base + 1, color = "black"),
      axis.line        = element_line(linewidth = 0.6, color = "black"),
      axis.ticks       = element_line(linewidth = 0.4, color = "black"),
      axis.ticks.length = unit(0.15, "cm"),
      axis.title       = element_text(face = "bold", size = base + 1, color = "black"),
      axis.text        = element_text(size = base, color = "black"),
      legend.key.size  = unit(0.4, "cm"),
      legend.title     = element_text(face = "bold", size = base),
      legend.text      = element_text(size = base - 1),
      legend.background = element_blank(),
      legend.key        = element_blank(),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      plot.margin      = margin(10, 12, 8, 10)
    )
}

clr_transform <- function(mat) {
  mat[mat < 0] <- 0
  nz <- mat[mat > 0]
  pseudo <- if (length(nz) > 0) min(nz) / 2 else 1e-6
  mat_p  <- mat + pseudo
  log_mp <- log(mat_p)
  gm     <- colMeans(log_mp)
  sweep(log_mp, 2, gm, "-")
}

extract_genus <- function(sp_names) sub("_.*$", "", sp_names)
fmt_sp <- function(x) gsub("_", " ", x)

build_net <- function(otu_sub, label = "", r_thr = R_THR, p_thr = P_THR, min_sp = 4) {
  sp_names <- rownames(otu_sub); n_sp <- length(sp_names); n_sa <- ncol(otu_sub)
  message("    [", label, "] ", n_sp, " sp x ", n_sa, " smp")
  if (n_sp < min_sp) { message("    -> too few species"); return(NULL) }

  clr_mat <- clr_transform(otu_sub)
  otu_T <- t(clr_mat)
  otu_T <- otu_T[, apply(otu_T, 2, var) > 0, drop = FALSE]
  if (ncol(otu_T) < min_sp) { message("    -> too few variable sp"); return(NULL) }
  suppressWarnings(cr <- WGCNA::corAndPvalue(otu_T, method = "spearman"))
  kept <- colnames(otu_T)
  r_mat <- matrix(0, n_sp, n_sp, dimnames = list(sp_names, sp_names))
  p_raw <- matrix(1, n_sp, n_sp, dimnames = list(sp_names, sp_names))
  r_mat[kept, kept] <- cr$cor; p_raw[kept, kept] <- cr$p
  diag(r_mat) <- 0; diag(p_raw) <- 1

  ij <- which(upper.tri(r_mat), arr.ind = TRUE)
  p_adj <- p.adjust(p_raw[ij], method = "BH")
  keep <- abs(r_mat[ij]) >= r_thr & !is.na(p_adj) & p_adj <= p_thr
  message("    -> edges: ", sum(keep), " (pos:", sum(r_mat[ij][keep] > 0),
          " neg:", sum(r_mat[ij][keep] < 0), ")")
  if (!any(keep)) { message("    -> no edges"); return(NULL) }

  edges_df <- tibble(from = colnames(r_mat)[ij[keep, 1]],
                     to   = colnames(r_mat)[ij[keep, 2]],
                     correlation = r_mat[ij][keep], p_adj = p_adj[keep])
  g <- graph_from_data_frame(edges_df, directed = FALSE,
                              vertices = unique(c(edges_df$from, edges_df$to)))
  set.seed(42); comm <- cluster_fast_greedy(g); memb <- membership(comm)
  deg <- degree(g); btw <- betweenness(g, normalized = TRUE)

  list(edges = edges_df,
       nodeprops = tibble(node = V(g)$name, degree = deg, betweenness = btw,
                          module = as.character(memb)),
       graph = g, membership = memb, r_mat = r_mat, p_mat = p_raw)
}

enrich_g <- function(net, sp_genus) {
  g <- net$graph
  g <- set_vertex_attr(g, "Genus",
    value = ifelse(V(g)$name %in% names(sp_genus), sp_genus[V(g)$name], "Other"))
  g <- set_vertex_attr(g, "module", value = as.character(net$membership[V(g)$name]))
  g <- set_vertex_attr(g, "deg",    value = degree(g))
  g
}

plot_net <- function(g, title, subtitle = NULL, genus_cols,
                     top_lbl = 15, sz_rng = c(3, 12), lbl_sz = 4.2,
                     leg = "right", title_col = "black") {
  set.seed(123); lay <- create_layout(g, layout = "fr")
  hubs <- lay %>% arrange(desc(deg)) %>% slice_head(n = top_lbl) %>% pull(name)
  lay <- lay %>% mutate(
    hub_label = if_else(name %in% hubs, fmt_sp(name), NA_character_),
    Genus_grp = if_else(Genus %in% names(genus_cols), Genus, "Other"))
  pal <- c(genus_cols, Other = "grey70")
  n_mod <- n_distinct(lay$module)
  sub <- subtitle %||%
    paste0(vcount(g), " species | ", ecount(g), " edges | ", n_mod, " modules")

  x_rng <- range(lay$x); y_rng <- range(lay$y)
  x_pad <- diff(x_rng) * 0.08; y_pad <- diff(y_rng) * 0.08

  ggraph(lay) +
    geom_edge_link(aes(color = ifelse(correlation >= 0, "Positive", "Negative"),
                       alpha = abs(correlation), width = abs(correlation)),
                   lineend = "round", show.legend = TRUE) +
    scale_edge_color_manual(values = c(Positive = EDGE_POS_COL, Negative = EDGE_NEG_COL),
                            name = "Correlation") +
    scale_edge_alpha(range = c(0.12, 0.75), guide = "none") +
    scale_edge_width(range = c(0.3, 1.6), guide = "none") +
    geom_node_point(aes(size = deg, fill = Genus_grp),
                    shape = 21, color = "white", stroke = 0.5, alpha = 0.92) +
    scale_size_continuous(range = sz_rng, name = "Degree") +
    scale_fill_manual(values = pal, name = "Genus") +
    geom_text_repel(data = filter(lay, !is.na(hub_label)),
                    aes(x = x, y = y, label = hub_label), inherit.aes = FALSE,
                    size = lbl_sz, fontface = "italic", max.overlaps = 60,
                    segment.alpha = 0.35, segment.size = 0.25,
                    box.padding = 0.35, point.padding = 0.25,
                    color = "black", seed = 42) +
    coord_cartesian(xlim = c(x_rng[1] - x_pad, x_rng[2] + x_pad),
                    ylim = c(y_rng[1] - y_pad, y_rng[2] + y_pad),
                    clip = "off") +
    theme_void(base_size = 10) +
    theme(plot.title = element_text(hjust = 0.5, face = "bold", size = 12,
                                     color = title_col, margin = margin(b = 2)),
          plot.subtitle = element_text(hjust = 0.5, color = "grey40", size = 9,
                                        margin = margin(b = 1)),
          legend.position = leg,
          legend.title = element_text(face = "bold", size = 9),
          legend.text = element_text(size = 8),
          legend.key.size = unit(0.35, "cm"),
          legend.margin = margin(0, 0, 0, 0),
          legend.spacing.y = unit(1, "pt"),
          plot.margin = margin(2, 2, 2, 2)) +
    guides(edge_color = guide_legend(order = 1, override.aes = list(edge_width = 1.5)),
           size = guide_legend(order = 2),
           fill = guide_legend(order = 3, override.aes = list(size = 4), ncol = 1)) +
    labs(title = title, subtitle = sub)
}

message("\n== Step 1: Load data ===")

abund_file <- file.path(WORK_DIR, "abundance_corrected.tsv")
ecst_file  <- file.path(WORK_DIR, "group.tsv")

hdr  <- strsplit(readLines(abund_file, n = 1), "\t")[[1]]
abnd <- read_tsv(abund_file, col_names = c("Species", hdr), skip = 1,
                 col_types = cols(.default = col_double(), Species = col_character()),
                 progress = FALSE)

ecst_df <- read_tsv(ecst_file, col_types = cols(), progress = FALSE)
ecst_types <- sort(unique(ecst_df$ECST))
if (!all(ecst_types %in% names(ECST_PAL))) {
  extra <- setdiff(ecst_types, names(ECST_PAL))
  extra_cols <- setNames(pal_npg("nrc")(length(extra)), extra)
  ECST_PAL <- c(ECST_PAL, extra_cols)
}
ECST_PAL <- ECST_PAL[ecst_types]
ECST_LEVELS <- names(ECST_PAL)
ecst_df$ECST <- factor(ecst_df$ECST, levels = ECST_LEVELS)
ecst_types <- ECST_LEVELS

common_smp <- intersect(hdr, ecst_df$sample_id)
otu_mat <- abnd %>% column_to_rownames("Species") %>%
  select(all_of(common_smp)) %>% as.matrix()
otu_mat[otu_mat < 0] <- 0
otu_mat <- otu_mat[rowSums(otu_mat) > 0, ]

sp_genus <- setNames(extract_genus(rownames(otu_mat)), rownames(otu_mat))
genus_tab <- sort(table(sp_genus), decreasing = TRUE)
genus_pal_pool <- c(
  "#E64B35", "#4DBBD5", "#00A087", "#3C5488", "#F39B7F",
  "#8491B4", "#91D1C2", "#DC9856", "#7E6148", "#B09C85",
  pal_d3("category10")(10))
GENUS_COLS <- setNames(genus_pal_pool[seq_along(genus_tab)], names(genus_tab))
GENUS_COLS["Other"] <- "grey70"

prev_global <- rowMeans(otu_mat > 1e-5)
keep_sp <- names(which(prev_global >= PREV_MIN))
ecst_map <- setNames(as.character(ecst_df$ECST), ecst_df$sample_id)

message("\n== Step 2: Per-ECST networks ===")
ecst_nets <- list()
for (ec in ecst_types) {
  smp_ec <- intersect(ecst_df$sample_id[ecst_df$ECST == ec], common_smp)
  if (length(smp_ec) < 15) next
  ec_otu <- otu_mat[keep_sp, smp_ec, drop = FALSE]
  net_ec <- build_net(ec_otu, label = ec)
  if (!is.null(net_ec)) {
    ecst_nets[[ec]] <- net_ec
    ec_dir <- file.path(RESULT_ROOT, ec)
    dir.create(ec_dir, showWarnings = FALSE)
    write_tsv(net_ec$edges,     file.path(ec_dir, "edges.tsv"))
    write_tsv(net_ec$nodeprops, file.path(ec_dir, "node_properties.tsv"))
  }
}

message("\n== Step 3: Figure 3C — Per-ECST network panel ===")
ecst_plots <- list()
for (ec in names(ecst_nets)) {
  net <- ecst_nets[[ec]]
  n_smp <- sum(ecst_map[common_smp] == ec, na.rm = TRUE)
  g_ec <- enrich_g(net, sp_genus)
  p_ec <- plot_net(g_ec,
    paste0(ec, " (n = ", n_smp, ")"),
    paste0(vcount(g_ec), " species | ", ecount(g_ec), " edges | ",
           round(mean(net$edges$correlation > 0) * 100), "% positive"),
    genus_cols = GENUS_COLS, top_lbl = min(10, vcount(g_ec)),
    sz_rng = c(2, 10), lbl_sz = 3.75, leg = "none",
    title_col = ECST_PAL[ec] %||% "black")
  ecst_plots[[ec]] <- p_ec
  save_fig(p_ec + theme(legend.position = "right"),
           paste0("Figure4C_", ec, "_network"), w = 7, h = 6)
}

if (length(ecst_plots) >= 2) {
  n_ecst <- length(ecst_plots)
  nc <- min(n_ecst, 2)
  fig_3C <- wrap_plots(ecst_plots, ncol = nc) +
    plot_layout(guides = "collect") &
    theme(legend.position = "right")
  fig_3C <- fig_3C + plot_annotation(tag_levels = "A")
  save_fig(fig_3C, "Figure4C_perECST_networks_panel",
           w = 7 * nc + 2, h = 6 * ceiling(n_ecst / nc))
  message("  Figure 3C saved")
}

message("\n== Step 4: Figure 3D — Network topology bar charts ===")

net_summary <- imap_dfr(ecst_nets, function(net, ec) {
  g <- net$graph
  n_v <- vcount(g); n_e <- ecount(g)
  tibble(
    ECST           = factor(ec, levels = ECST_LEVELS),
    n_samples      = sum(ecst_map[common_smp] == ec, na.rm = TRUE),
    n_species      = n_v,
    n_edges        = n_e,
    density        = n_e / (n_v * (n_v - 1) / 2),
    mean_degree    = mean(degree(g)),
    mean_btw       = mean(betweenness(g, normalized = TRUE)),
    modularity_val = modularity(cluster_fast_greedy(g)),
    pos_pct        = mean(net$edges$correlation > 0) * 100
  )
})
write_tsv(net_summary, file.path(SUMMARY_DIR, "network_topology_comparison.tsv"))

p_edges <- ggplot(net_summary, aes(x = ECST, y = n_edges, fill = ECST)) +
  geom_col(width = 0.55, color = "black", linewidth = 0.3) +
  geom_text(aes(label = n_edges), vjust = -0.4, size = 3.5, fontface = "bold") +
  scale_fill_manual(values = ECST_PAL, drop = FALSE) +
  scale_x_discrete(drop = FALSE) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.18))) +
  theme_cns(9) + theme(legend.position = "none") +
  labs(x = NULL, y = "Number of edges")

p_degree <- ggplot(net_summary, aes(x = ECST, y = mean_degree, fill = ECST)) +
  geom_col(width = 0.55, color = "black", linewidth = 0.3) +
  geom_text(aes(label = round(mean_degree, 3)), vjust = -0.4, size = 3.5, fontface = "bold") +
  scale_fill_manual(values = ECST_PAL, drop = FALSE) +
  scale_x_discrete(drop = FALSE) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.18))) +
  theme_cns(9) + theme(legend.position = "none") +
  labs(x = NULL, y = "Mean degree")

fig_3D <- (p_edges / p_degree) +
  plot_annotation(tag_levels = "A")
save_fig(fig_3D, "Figure4D_topology_barplots", data = net_summary, w = 5, h = 8)
message("  Figure 3D saved")

message("\n== Analysis complete ===")
message("Outputs: ", RESULT_ROOT)
